const searchInput = document.getElementById("searchInput");
const resultsDiv = document.getElementById("results");

function search(type) {
  const query = searchInput.value.trim();
  if (!query) return alert("Enter a topic to search.");

  // Check if YouTube API key is available
  if (type === 'videos' && (!YOUTUBE_API_KEY || YOUTUBE_API_KEY === '')) {
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = `
      <div class="error-message" style="text-align: center; padding: 40px; color: #EF4444;">
        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 20px;"></i>
        <h3>YouTube API Key Missing</h3>
        <p style="color: #B8C5D1;">The YouTube API key is not configured.</p>
        <p style="color: #8A95A3; margin-top: 15px;">Please check config.js file.</p>
      </div>
    `;
    return;
  }

  // Update active tab state
  updateActiveTab(type);

  // Hide recommendations for non-home tabs
  const recBox = document.getElementById("recommendationBox");
  recBox.style.display = "none";

  showSkeleton();
  logSearch(query, type);

  if (type === 'videos') searchYouTube(query, "results", true);
  if (type === 'code') searchGitHub(query, "results", true);
  if (type === 'papers') searchPapers(query, "results", true);
  if (type === 'datasets') searchKaggle(query, "results", true);
}

function updateActiveTab(activeType) {
  // Remove active class from all tabs
  const tabs = document.querySelectorAll('.tabs button');
  tabs.forEach(tab => tab.classList.remove('active'));

  // Add active class to current tab
  let selector = '';
  if (activeType === 'home') {
    selector = '.tabs button[onclick="goHome()"]';
  } else if (activeType === 'videos') {
    selector = '.tabs button[onclick="search(\'videos\')"]';
  } else if (activeType === 'code') {
    selector = '.tabs button[onclick="search(\'code\')"]';
  } else if (activeType === 'papers') {
    selector = '.tabs button[onclick="search(\'papers\')"]';
  } else if (activeType === 'datasets') {
    selector = '.tabs button[onclick="search(\'datasets\')"]';
  }

  const activeTab = document.querySelector(selector);
  if (activeTab) {
    activeTab.classList.add('active');
  }
}

function showSkeleton() {
  resultsDiv.innerHTML = "";
  resultsDiv.className = "results";
  showSkeletonInContainer(resultsDiv, 15);
}

function showSkeletonInContainer(container, count = 10) {
  for (let i = 0; i < count; i++) {
    const skeleton = document.createElement("div");
    skeleton.classList.add("result-card", "skeleton-card");
    skeleton.innerHTML = `
      <div class="skeleton skeleton-image"></div>
      <div class="skeleton skeleton-title"></div>
      <div class="skeleton skeleton-text"></div>
      <div class="skeleton skeleton-text short"></div>
      <div class="skeleton skeleton-rank"></div>
    `;
    container.appendChild(skeleton);
  }
}

function logSearch(query, type) {
  fetch("log_search.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `query=${encodeURIComponent(query)}&type=${type}`
  });
}

/* ---------------- Home Page ---------------- */
async function goHome() {
  // Update active tab state
  updateActiveTab('home');

  const recBox = document.getElementById("recommendationBox");

  // Show recommendations box for home tab
  recBox.style.display = "block";
  recBox.innerHTML = '<p><i class="fas fa-lightbulb"></i> Start searching to get personalized recommendations!</p>';

  // Modern Home Page Layout
  resultsDiv.innerHTML = `
    
  `;

  try {
    const res = await fetch("get_history.php");
    const queries = await res.json();

    if (!queries.length || !queries[0]) {
      recBox.innerHTML = "<p>No search history yet. Try searching first.</p>";
      return;
    }

    const query = queries[0];

    // Generate enhanced query variations for better recommendations
    const enhancedQueries = generateEnhancedQueries(query);

    recBox.innerHTML = `
      <div class="premium-recommendation-header">
        <h2><i class="fas fa-crown premium-icon"></i> You May Also Like</h2>
        <p class="recommendation-subtitle">AI-powered suggestions based on: <em>"${query}"</em></p>
        <div class="recommendation-stats">
          <span class="stat-badge"><i class="fas fa-brain"></i> Smart Analysis</span>
          <span class="stat-badge"><i class="fas fa-trending-up"></i> Trending Content</span>
          <span class="stat-badge"><i class="fas fa-star"></i> Quality Ranked</span>
        </div>
      </div>
      <div class="recommendations-grid premium-grid">
        <div class="recommendation-section premium-section">
          <div class="section-header">
            <h3><i class="fas fa-video premium-icon"></i> Premium Videos</h3>
            <span class="loading-indicator" id="videoLoader"><i class="fas fa-spinner fa-spin"></i></span>
          </div>
          <div id="recVideos" class="recommendation-results premium-results"></div>
        </div>
        <div class="recommendation-section premium-section">
          <div class="section-header">
            <h3><i class="fas fa-code premium-icon"></i> Elite Code Repositories</h3>
            <span class="loading-indicator" id="codeLoader"><i class="fas fa-spinner fa-spin"></i></span>
          </div>
          <div id="recCode" class="recommendation-results premium-results"></div>
        </div>
        <div class="recommendation-section premium-section">
          <div class="section-header">
            <h3><i class="fas fa-file-alt premium-icon"></i> Research Papers</h3>
            <span class="loading-indicator" id="papersLoader"><i class="fas fa-spinner fa-spin"></i></span>
          </div>
          <div id="recPapers" class="recommendation-results premium-results"></div>
        </div>
        <div class="recommendation-section premium-section">
          <div class="section-header">
            <h3><i class="fas fa-chart-bar premium-icon"></i> Premium Datasets</h3>
            <span class="loading-indicator" id="datasetsLoader"><i class="fas fa-spinner fa-spin"></i></span>
          </div>
          <div id="recDatasets" class="recommendation-results premium-results"></div>
        </div>
      </div>
    `;

    // Load premium recommendations with enhanced algorithms
    searchPremiumYouTube(enhancedQueries, "recVideos");
    searchPremiumGitHub(enhancedQueries, "recCode");
    searchPremiumPapers(enhancedQueries, "recPapers");
    searchPremiumKaggle(enhancedQueries, "recDatasets");
  } catch {
    recBox.innerHTML = "<p>Error loading recommendations.</p>";
  }
}

/* ---------------- Enhanced Recommendation Functions ---------------- */

// Generate enhanced query variations for better recommendations
function generateEnhancedQueries(originalQuery) {
  const synonyms = {
    'ai': ['artificial intelligence', 'machine learning', 'deep learning', 'neural networks'],
    'ml': ['machine learning', 'artificial intelligence', 'data science', 'predictive modeling'],
    'web': ['website', 'frontend', 'backend', 'full stack', 'web development'],
    'app': ['application', 'mobile app', 'software', 'development'],
    'data': ['dataset', 'analytics', 'big data', 'data science', 'visualization'],
    'python': ['programming', 'coding', 'development', 'scripting'],
    'javascript': ['js', 'frontend', 'web development', 'nodejs'],
    'react': ['frontend', 'ui', 'component', 'javascript'],
    'api': ['rest api', 'web service', 'integration', 'backend']
  };

  const queries = [originalQuery];
  const words = originalQuery.toLowerCase().split(' ');

  words.forEach(word => {
    if (synonyms[word]) {
      synonyms[word].forEach(synonym => {
        queries.push(originalQuery.replace(new RegExp(word, 'gi'), synonym));
      });
    }
  });

  // Add trending keywords
  const trendingKeywords = ['2024', '2025', 'latest', 'tutorial', 'guide', 'best practices'];
  trendingKeywords.forEach(keyword => {
    queries.push(`${originalQuery} ${keyword}`);
  });

  return [...new Set(queries)].slice(0, 5); // Return unique queries, max 5
}

// Premium YouTube search with advanced ranking
async function searchPremiumYouTube(queries, containerId) {
  const container = document.getElementById(containerId);
  const loader = document.getElementById('videoLoader');

  try {
    let allVideos = [];

    // Search with multiple enhanced queries
    for (const query of queries) {
      const endpoint = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=10&q=${encodeURIComponent(query)}&key=${YOUTUBE_API_KEY}&order=relevance`;
      const res = await fetch(endpoint);
      const data = await res.json();

      if (data.items) {
        allVideos = allVideos.concat(data.items.map(item => ({ ...item, searchQuery: query })));
      }
    }

    if (!allVideos.length) {
      container.innerHTML = "<p>No premium videos found.</p>";
      loader.style.display = 'none';
      return;
    }

    // Remove duplicates by video ID
    const uniqueVideos = allVideos.filter((video, index, self) =>
      index === self.findIndex(v => v.id.videoId === video.id.videoId)
    );

    const videoIds = uniqueVideos.map(item => item.id.videoId);
    const stats = await fetchVideoStats(videoIds);

    // Enhanced scoring algorithm
    let scoredVideos = uniqueVideos.map(item => {
      const s = stats[item.id.videoId] || {};
      const views = parseInt(s.viewCount || 0);
      const likes = parseInt(s.likeCount || 0);
      const comments = parseInt(s.commentCount || 0);

      // Advanced scoring: views (40%), likes (30%), comments (20%), recency (10%)
      const publishDate = new Date(item.snippet.publishedAt);
      const daysSincePublish = (Date.now() - publishDate.getTime()) / (1000 * 60 * 60 * 24);
      const recencyScore = Math.max(0, 365 - daysSincePublish) / 365;

      const score = (0.4 * views) + (0.3 * likes) + (0.2 * comments) + (0.1 * recencyScore * 1000000);

      return { ...item, score, views, likes, comments };
    });

    scoredVideos.sort((a, b) => b.score - a.score);

    container.innerHTML = "";
    scoredVideos.slice(0, 8).forEach((item, idx) => {
      const title = item.snippet.title;
      const thumbnail = item.snippet.thumbnails.medium.url;
      const channel = item.snippet.channelTitle;
      const videoUrl = `https://www.youtube.com/watch?v=${item.id.videoId}`;
      const viewCount = formatNumber(item.views);
      const likeCount = formatNumber(item.likes);

      container.innerHTML += `
        <div class="premium-result-card">
          <div class="premium-badge">
            <i class="fas fa-crown"></i> Premium #${idx + 1}
          </div>
          <a href="${videoUrl}" target="_blank">
            <img src="${thumbnail}" alt="${title}" loading="lazy">
            <div class="premium-content">
              <h4>${title}</h4>
              <p class="channel-name"><i class="fas fa-user"></i> ${channel}</p>
              <div class="premium-stats">
                <span><i class="fas fa-eye"></i> ${viewCount}</span>
                <span><i class="fas fa-thumbs-up"></i> ${likeCount}</span>
              </div>
            </div>
          </a>
        </div>
      `;
    });

    loader.style.display = 'none';
  } catch (error) {
    console.error('Premium YouTube search error:', error);
    const isQuotaError = error.message && (
      error.message.includes('403') || 
      error.message.includes('quota') || 
      error.message.includes('Forbidden')
    );
    container.innerHTML = `
      <p style="color: #EF4444;">
        ${isQuotaError ? '⚠️ API Quota Exceeded - Videos unavailable' : 'Error fetching premium videos'}
      </p>
    `;
    loader.style.display = 'none';
  }
}

// Premium GitHub search with enhanced ranking
async function searchPremiumGitHub(queries, containerId) {
  const container = document.getElementById(containerId);
  const loader = document.getElementById('codeLoader');

  try {
    let allRepos = [];

    // Search with multiple enhanced queries using public API access
    for (const query of queries) {
      const endpoint = `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&order=desc&per_page=10`;
      const res = await fetch(endpoint, {
        headers: {
          'Accept': 'application/vnd.github.v3+json'
        }
      });
      const data = await res.json();

      if (data.items) {
        allRepos = allRepos.concat(data.items.map(item => ({ ...item, searchQuery: query })));
      }
    }

    if (!allRepos.length) {
      container.innerHTML = "<p>No premium repositories found.</p>";
      loader.style.display = 'none';
      return;
    }

    // Remove duplicates by repo ID
    const uniqueRepos = allRepos.filter((repo, index, self) =>
      index === self.findIndex(r => r.id === repo.id)
    );

    // Enhanced scoring algorithm
    let scoredRepos = uniqueRepos.map(repo => {
      const stars = repo.stargazers_count || 0;
      const forks = repo.forks_count || 0;
      const watchers = repo.watchers_count || 0;
      const issues = repo.open_issues_count || 0;

      // Check for recent activity
      const lastUpdate = new Date(repo.updated_at);
      const daysSinceUpdate = (Date.now() - lastUpdate.getTime()) / (1000 * 60 * 60 * 24);
      const activityScore = Math.max(0, 365 - daysSinceUpdate) / 365;

      // Premium scoring: stars (50%), forks (20%), activity (15%), watchers (10%), few issues (5%)
      const issuesPenalty = Math.max(0, 1 - (issues / 100));
      const score = (0.5 * stars) + (0.2 * forks) + (0.15 * activityScore * 1000) + (0.1 * watchers) + (0.05 * issuesPenalty * 100);

      return { ...repo, score, activityScore };
    });

    scoredRepos.sort((a, b) => b.score - a.score);

    container.innerHTML = "";
    scoredRepos.slice(0, 8).forEach((repo, idx) => {
      const desc = repo.description ? repo.description.replace(/</g, "&lt;").substring(0, 120) : 'No description';
      const language = repo.language || 'Unknown';
      const stars = formatNumber(repo.stargazers_count);
      const forks = formatNumber(repo.forks_count);

      container.innerHTML += `
        <div class="premium-result-card">
          <div class="premium-badge">
            <i class="fas fa-star"></i> Elite #${idx + 1}
          </div>
          <a href="${repo.html_url}" target="_blank">
            <div class="premium-content">
              <h4>${repo.full_name}</h4>
              <p>${desc}...</p>
              <div class="premium-stats">
                <span class="language-tag">${language}</span>
                <span><i class="fas fa-star"></i> ${stars}</span>
                <span><i class="fas fa-code-branch"></i> ${forks}</span>
              </div>
            </div>
          </a>
        </div>
      `;
    });

    loader.style.display = 'none';
  } catch (error) {
    container.innerHTML = "<p>Error fetching premium repositories.</p>";
    loader.style.display = 'none';
  }
}

// Premium Papers search with enhanced ranking
async function searchPremiumPapers(queries, containerId) {
  const container = document.getElementById(containerId);
  const loader = document.getElementById('papersLoader');

  try {
    let allPapers = [];

    // Search with multiple enhanced queries
    for (const query of queries) {
      const endpoint = `api_proxy.php?api=arxiv&query=${encodeURIComponent(query)}`;
      const res = await fetch(endpoint);
      const data = await res.json();
      
      if (!data.success || !data.xml) continue;
      
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(data.xml, "text/xml");
      const entries = xmlDoc.getElementsByTagName("entry");

      Array.from(entries).forEach(entry => {
        const title = entry.getElementsByTagName("title")[0]?.textContent || "Untitled";
        const link = entry.getElementsByTagName("id")[0]?.textContent || "#";
        const summary = entry.getElementsByTagName("summary")[0]?.textContent || "No summary";
        const published = entry.getElementsByTagName("published")[0]?.textContent || "";
        const authors = Array.from(entry.getElementsByTagName("author")).map(author =>
          author.getElementsByTagName("name")[0]?.textContent || "Unknown"
        );

        allPapers.push({ title, link, summary, published, authors, searchQuery: query });
      });
    }

    if (!allPapers.length) {
      container.innerHTML = "<p>No premium papers found.</p>";
      loader.style.display = 'none';
      return;
    }

    // Remove duplicates by title similarity
    const uniquePapers = allPapers.filter((paper, index, self) =>
      index === self.findIndex(p => p.title.toLowerCase() === paper.title.toLowerCase())
    );

    // Enhanced scoring algorithm
    let scoredPapers = uniquePapers.map(paper => {
      const publishDate = new Date(paper.published);
      const year = publishDate.getFullYear();
      const currentYear = new Date().getFullYear();

      // Premium scoring: recency (60%), author count (20%), title relevance (20%)
      const recencyScore = Math.max(0, 1 - ((currentYear - year) / 10));
      const authorScore = Math.min(1, paper.authors.length / 5);
      const titleWords = paper.title.toLowerCase().split(' ').length;
      const titleScore = Math.min(1, titleWords / 10);

      const score = (0.6 * recencyScore) + (0.2 * authorScore) + (0.2 * titleScore);

      return { ...paper, score, year };
    });

    scoredPapers.sort((a, b) => b.score - a.score);

    container.innerHTML = "";
    scoredPapers.slice(0, 8).forEach((paper, idx) => {
      const authorList = paper.authors.slice(0, 3).join(', ') + (paper.authors.length > 3 ? ' et al.' : '');

      container.innerHTML += `
        <div class="premium-result-card">
          <div class="premium-badge">
            <i class="fas fa-graduation-cap"></i> Research #${idx + 1}
          </div>
          <a href="${paper.link}" target="_blank">
            <div class="premium-content">
              <h4>${paper.title}</h4>
              <p class="authors"><i class="fas fa-users"></i> ${authorList}</p>
              <p>${paper.summary.slice(0, 120)}...</p>
              <div class="premium-stats">
                <span><i class="fas fa-calendar"></i> ${paper.year}</span>
                <span><i class="fas fa-file-alt"></i> arXiv</span>
              </div>
            </div>
          </a>
        </div>
      `;
    });

    loader.style.display = 'none';
  } catch (error) {
    container.innerHTML = "<p>Error fetching premium papers.</p>";
    loader.style.display = 'none';
  }
}

// Premium Kaggle search with enhanced ranking
async function searchPremiumKaggle(queries, containerId) {
  const container = document.getElementById(containerId);
  const loader = document.getElementById('datasetsLoader');

  try {
    let allDatasets = [];
    const auth = btoa(`${KAGGLE_USERNAME}:${KAGGLE_KEY}`);

    // Search with multiple enhanced queries
    for (const query of queries) {
      const endpoint = `https://www.kaggle.com/api/v1/datasets/list?search=${encodeURIComponent(query)}&pageSize=10&sortBy=hottest`;
      const res = await fetch(endpoint, {
        headers: { "Authorization": `Basic ${auth}` }
      });

      if (res.ok) {
        const data = await res.json();
        allDatasets = allDatasets.concat(data.map(item => ({ ...item, searchQuery: query })));
      }
    }

    if (!allDatasets.length) {
      container.innerHTML = "<p>No premium datasets found.</p>";
      loader.style.display = 'none';
      return;
    }

    // Remove duplicates by ref
    const uniqueDatasets = allDatasets.filter((dataset, index, self) =>
      index === self.findIndex(d => d.ref === dataset.ref)
    );

    // Enhanced scoring algorithm
    let scoredDatasets = uniqueDatasets.map(ds => {
      const downloads = ds.downloadCount || 0;
      const usability = ds.usabilityRating || 0;
      const views = ds.viewCount || 0;
      const votes = ds.voteCount || 0;

      // Premium scoring: usability (40%), downloads (30%), views (20%), votes (10%)
      const score = (0.4 * usability) + (0.3 * Math.log10(downloads + 1)) + (0.2 * Math.log10(views + 1)) + (0.1 * votes);

      return { ...ds, score };
    });

    scoredDatasets.sort((a, b) => b.score - a.score);

    container.innerHTML = "";
    scoredDatasets.slice(0, 8).forEach((ds, idx) => {
      const title = ds.title || "Untitled Dataset";
      const desc = ds.subtitle || "No description";
      const link = `https://www.kaggle.com/datasets/${ds.ref}`;
      const downloads = formatNumber(ds.downloadCount);
      const usability = ds.usabilityRating ? ds.usabilityRating.toFixed(1) : 'N/A';

      container.innerHTML += `
        <div class="premium-result-card">
          <div class="premium-badge">
            <i class="fas fa-database"></i> Premium #${idx + 1}
          </div>
          <a href="${link}" target="_blank">
            <div class="premium-content">
              <h4>${title}</h4>
              <p>${desc.slice(0, 120)}...</p>
              <div class="premium-stats">
                <span><i class="fas fa-download"></i> ${downloads}</span>
                <span><i class="fas fa-star"></i> ${usability}</span>
                <span><i class="fas fa-chart-line"></i> Kaggle</span>
              </div>
            </div>
          </a>
        </div>
      `;
    });

    loader.style.display = 'none';
  } catch (error) {
    container.innerHTML = "<p>Error fetching premium datasets.</p>";
    loader.style.display = 'none';
  }
}

// Utility function to format large numbers
function formatNumber(num) {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num ? num.toString() : '0';
}

/* ---------------- Original Ranking Functions ---------------- */

// YouTube
async function fetchVideoStats(videoIds) {
  try {
    if (!videoIds || videoIds.length === 0) {
      return {};
    }
    
    const statsEndpoint = `https://www.googleapis.com/youtube/v3/videos?part=statistics&id=${videoIds.join(",")}&key=${YOUTUBE_API_KEY}`;
    const res = await fetch(statsEndpoint);
    
    if (!res.ok) {
      console.error('Failed to fetch video stats:', res.status, res.statusText);
      return {};
    }
    
    const data = await res.json();
    
    if (!data.items || !Array.isArray(data.items)) {
      console.error('Invalid response from YouTube API:', data);
      return {};
    }
    
    return data.items.reduce((map, item) => {
      map[item.id] = item.statistics;
      return map;
    }, {});
  } catch (error) {
    console.error('Error fetching video stats:', error);
    return {};
  }
}

async function searchYouTube(query, containerId = "results", clear = false) {
  const container = document.getElementById(containerId);
  if (clear) {
    container.innerHTML = "";
    showSkeletonInContainer(container);
  }
  container.className = "results";

  const endpoint = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=25&q=${encodeURIComponent(query)}&key=${YOUTUBE_API_KEY}`;
  
  console.log('YouTube API Key:', YOUTUBE_API_KEY ? 'Present' : 'Missing');
  console.log('YouTube API Endpoint:', endpoint);
  
  try {
    const res = await fetch(endpoint);
    const data = await res.json();

    console.log('YouTube API Response Status:', res.status);
    console.log('YouTube API Response Data:', data);

    // Clear skeleton loader
    container.innerHTML = "";

    // Check for API errors
    if (data.error) {
      throw new Error(data.error.message || 'YouTube API Error: ' + JSON.stringify(data.error));
    }

    if (!data.items || data.items.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 40px; color: #8A95A3;">
          <i class="fas fa-video" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.5;"></i>
          <h3>No Videos Found</h3>
          <p>Try searching with different keywords or check:</p>
          <ul style="list-style: none; padding: 0; margin-top: 15px;">
            <li>✓ Spelling of your search terms</li>
            <li>✓ Using more general keywords</li>
            <li>✓ Using different related terms</li>
          </ul>
        </div>
      `;
      return;
    }

    const videoIds = data.items.map(item => item.id.videoId);
    
    // Fetch video statistics
    let stats = {};
    try {
      stats = await fetchVideoStats(videoIds);
    } catch (statsError) {
      console.warn('Could not fetch video stats:', statsError);
      // Continue without stats
    }

    let scoredVideos = data.items.map(item => {
      const s = stats[item.id.videoId] || {};
      const views = parseInt(s.viewCount || 0);
      const likes = parseInt(s.likeCount || 0);
      const score = (0.6 * views) + (0.4 * likes);
      return { ...item, score, views, likes };
    });

    scoredVideos.sort((a, b) => b.score - a.score);

    scoredVideos.forEach((item, idx) => {
      const title = item.snippet.title;
      const thumbnail = item.snippet.thumbnails.medium.url;
      const channel = item.snippet.channelTitle;
      const videoUrl = `https://www.youtube.com/watch?v=${item.id.videoId}`;
      const viewCount = item.views > 0 ? `${formatNumber(item.views)} views` : '';
      
      container.innerHTML += `
        <div class="result-card">
          <a href="${videoUrl}" target="_blank">
            <img src="${thumbnail}" alt="${title}" loading="lazy">
            <h3>${title}</h3>
            <p><i class="fas fa-user"></i> ${channel}</p>
            ${viewCount ? `<p><i class="fas fa-eye"></i> ${viewCount}</p>` : ''}
            <p><strong>Rank ${idx + 1}</strong></p>
          </a>
        </div>
      `;
    });
    
    console.log(`Successfully displayed ${scoredVideos.length} videos`);
  } catch (error) {
    console.error('YouTube search error:', error);
    
    // Check if it's a quota error
    const isQuotaError = error.message && (
      error.message.includes('403') || 
      error.message.includes('quota') || 
      error.message.includes('Forbidden')
    );
    
    container.innerHTML = `
      <div class="error-message" style="text-align: center; padding: 40px; color: #EF4444;">
        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 20px;"></i>
        <h3>${isQuotaError ? '🚫 YouTube API Quota Exceeded' : 'Error Fetching Videos'}</h3>
        ${isQuotaError ? `
          <div style="max-width: 700px; margin: 20px auto; text-align: left; background: rgba(255,255,255,0.05); padding: 25px; border-radius: 15px;">
            <p style="color: #B8C5D1; margin-bottom: 20px; font-size: 1.1rem;">
              ⚠️ The YouTube API has reached its <strong>daily quota limit of 10,000 units</strong>.
            </p>
            
            <div style="background: rgba(0,210,255,0.1); padding: 20px; border-radius: 10px; border-left: 4px solid #00D2FF; margin: 20px 0;">
              <h4 style="color: #00D2FF; margin-top: 0;">📋 Solutions Available:</h4>
              <ol style="color: #B8C5D1; margin: 10px 0; line-height: 1.8;">
                <li><strong>Wait for Reset:</strong> Quota resets daily at midnight PST (Pacific Time)</li>
                <li><strong>Use YouTube Directly:</strong> Click button below to search on YouTube.com</li>
                <li><strong>Get New API Key:</strong> Administrator can create a new key at <a href="https://console.cloud.google.com/apis/credentials" target="_blank" style="color: #00D2FF;">Google Cloud Console</a></li>
                <li><strong>Upgrade Quota:</strong> Request quota increase in Google Cloud Console (up to 1M units/day)</li>
              </ol>
            </div>
            
            <div style="background: rgba(255,200,0,0.1); padding: 15px; border-radius: 10px; margin: 15px 0;">
              <p style="color: #FFC800; margin: 0; font-size: 0.95rem;">
                <i class="fas fa-lightbulb"></i> <strong>Tip:</strong> Each search costs ~100 quota units. 
                Consider caching results or using multiple API keys for high-traffic applications.
              </p>
            </div>
          </div>
        ` : `
          <p style="color: #B8C5D1;">Unable to retrieve YouTube videos. Please check your internet connection.</p>
        `}
        <p style="font-size: 0.9rem; color: #8A95A3; margin-top: 15px;">Technical Error: ${error.message || 'Network error'}</p>
        <div style="margin-top: 25px; display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
          <a href="https://www.youtube.com/results?search_query=${encodeURIComponent(query)}" 
             target="_blank"
             style="display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #FF0000 0%, #CC0000 100%); 
                    color: white; text-decoration: none; border-radius: 25px; font-weight: 600; box-shadow: 0 4px 15px rgba(255,0,0,0.3);">
            <i class="fab fa-youtube"></i> Search on YouTube.com
          </a>
          <button onclick="location.reload()" 
                  style="padding: 12px 30px; background: linear-gradient(135deg, #00D2FF 0%, #3A7BD5 100%); 
                         color: white; border: none; border-radius: 25px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 15px rgba(0,210,255,0.3);">
            <i class="fas fa-sync-alt"></i> Refresh Page
          </button>
        </div>
        ${isQuotaError ? `
          <div style="margin-top: 25px; padding: 20px; background: rgba(0,0,0,0.3); border-radius: 10px; max-width: 600px; margin-left: auto; margin-right: auto;">
            <p style="color: #8A95A3; font-size: 0.9rem; margin: 0;">
              <i class="fas fa-info-circle"></i> <strong>For Administrators:</strong><br>
              Update API key in <code style="background: rgba(255,255,255,0.1); padding: 2px 8px; border-radius: 4px;">config.js</code> and 
              <code style="background: rgba(255,255,255,0.1); padding: 2px 8px; border-radius: 4px;">config.php</code>
            </p>
          </div>
        ` : ''}
      </div>
    `;
  }
}

// GitHub
async function searchGitHub(query, containerId = "results", clear = false) {
  const container = document.getElementById(containerId);
  if (clear) {
    container.innerHTML = "";
    showSkeletonInContainer(container);
  }
  container.className = "results";

  // Public API access without authentication
  const endpoint = `https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&sort=stars&order=desc&per_page=25`;
  
  console.log('GitHub API Endpoint:', endpoint);
  
  try {
    // Public API call with proper headers for rate limit visibility
    const res = await fetch(endpoint, {
      headers: {
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'StudySearchEngine'
      }
    });
    
    const data = await res.json();
    
    console.log('GitHub API Response Status:', res.status);
    console.log('GitHub API Response Data:', data);
    
    // Clear skeleton loader
    container.innerHTML = "";

    // Check if response is ok
    if (!res.ok) {
      const errorMessage = data.message || `HTTP ${res.status}: ${res.statusText}`;
      throw new Error(errorMessage);
    }

    if (!data.items || data.items.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 40px; color: #8A95A3;">
          <i class="fas fa-code" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.5;"></i>
          <h3>No Code Repositories Found</h3>
          <p>Try searching with different programming keywords</p>
          <ul style="list-style: none; padding: 0; margin-top: 15px;">
            <li>✓ Use programming language names (e.g., "javascript", "python")</li>
            <li>✓ Try framework names (e.g., "react", "django")</li>
            <li>✓ Search for specific topics (e.g., "machine learning")</li>
          </ul>
        </div>
      `;
      return;
    }

    let scoredRepos = data.items.map(repo => {
      const stars = repo.stargazers_count || 0;
      const forks = repo.forks_count || 0;
      const score = (0.7 * stars) + (0.3 * forks);
      return { ...repo, score };
    });

    scoredRepos.sort((a, b) => b.score - a.score);

    scoredRepos.slice(0, 25).forEach((repo, idx) => {
      const desc = repo.description ? repo.description.replace(/</g, "&lt;").substring(0, 150) : 'No description';
      const language = repo.language || 'Unknown';
      const stars = formatNumber(repo.stargazers_count || 0);
      const forks = formatNumber(repo.forks_count || 0);
      
      container.innerHTML += `
        <div class="result-card">
          <a href="${repo.html_url}" target="_blank">
            <h3><i class="fab fa-github"></i> ${repo.full_name}</h3>
            <p>${desc}...</p>
            <p><span class="language-tag" style="background: #00D2FF; color: #fff; padding: 2px 8px; border-radius: 3px; font-size: 0.85em;">${language}</span></p>
            <p><i class="fas fa-star"></i> ${stars} stars · <i class="fas fa-code-branch"></i> ${forks} forks</p>
            <p><strong>Rank ${idx + 1}</strong></p>
          </a>
        </div>
      `;
    });
    
    console.log(`Successfully displayed ${scoredRepos.length} repositories`);
  } catch (error) {
    console.error('GitHub search error:', error);
    container.innerHTML = `
      <div class="error-message" style="text-align: center; padding: 40px; color: #EF4444;">
        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 20px;"></i>
        <h3>Error Fetching Repositories</h3>
        <p>Unable to retrieve GitHub repositories. This could be due to:</p>
        <ul style="text-align: left; max-width: 500px; margin: 20px auto; color: #B8C5D1;">
          <li>GitHub API rate limit exceeded</li>
          <li>Network connectivity issues</li>
          <li>Invalid search query</li>
        </ul>
        <p style="font-size: 0.9rem; color: #8A95A3; margin-top: 15px;">Error: ${error.message || 'Network error'}</p>
      </div>
    `;
  }
}

// Papers
async function searchPapers(query, containerId = "results", clear = false) {
  const container = document.getElementById(containerId);
  if (clear) {
    container.innerHTML = "";
    showSkeletonInContainer(container);
  }
  container.className = "results";

  // Use proxy to bypass CORS
  const endpoint = `api_proxy.php?api=arxiv&query=${encodeURIComponent(query)}`;
  try {
    const res = await fetch(endpoint);
    
    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.error || `HTTP ${res.status}`);
    }
    
    const data = await res.json();
    
    if (!data.success || !data.xml) {
      throw new Error('Invalid response from proxy');
    }
    
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(data.xml, "text/xml");
    const entries = xmlDoc.getElementsByTagName("entry");

    // Clear skeleton loader
    container.innerHTML = "";

    if (!entries.length) {
      container.innerHTML = `
        <div style="text-align: center; padding: 40px; color: #8A95A3;">
          <i class="fas fa-file-alt" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.5;"></i>
          <h3>No Research Papers Found</h3>
          <p>Try searching with different academic keywords</p>
        </div>
      `;
      return;
    }

    let scoredPapers = Array.from(entries).map(entry => {
      const title = entry.getElementsByTagName("title")[0]?.textContent || "Untitled";
      const link = entry.getElementsByTagName("id")[0]?.textContent || "#";
      const summary = entry.getElementsByTagName("summary")[0]?.textContent || "No summary available";
      const published = entry.getElementsByTagName("published")[0]?.textContent;
      const year = published ? new Date(published).getFullYear() : new Date().getFullYear();
      const currentYear = new Date().getFullYear();
      const recencyScore = 1 / (currentYear - year + 1);
      return { title, link, summary, score: recencyScore };
    });

    scoredPapers.sort((a, b) => b.score - a.score);

    scoredPapers.forEach((paper, idx) => {
      container.innerHTML += `
        <div class="result-card">
          <a href="${paper.link}" target="_blank">
            <h3>${paper.title}</h3>
            <p>${paper.summary.slice(0, 150)}...</p>
            <p><strong>Rank ${idx + 1}</strong></p>
          </a>
        </div>
      `;
    });
  } catch (error) {
    console.error('Papers search error:', error);
    container.innerHTML = `
      <div class="error-message" style="text-align: center; padding: 40px; color: #EF4444;">
        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 20px;"></i>
        <h3>Error Fetching Papers</h3>
        <p>Unable to retrieve research papers from arXiv.</p>
        <p style="font-size: 0.9rem; color: #8A95A3; margin-top: 15px;">Error: ${error.message || 'Network error'}</p>
        <button onclick="searchPapers('${query.replace(/'/g, "\\'")}', 'results', true)" 
                style="margin-top: 20px; padding: 10px 25px; background: linear-gradient(135deg, #00D2FF 0%, #3A7BD5 100%); 
                       color: white; border: none; border-radius: 25px; cursor: pointer; font-weight: 600;">
          <i class="fas fa-redo"></i> Try Again
        </button>
      </div>
    `;
  }
}

// Kaggle
async function searchKaggle(query, containerId = "results", clear = false) {
  const container = document.getElementById(containerId);
  if (clear) {
    container.innerHTML = "";
    showSkeletonInContainer(container);
  }
  container.className = "results";

  const auth = btoa(`${KAGGLE_USERNAME}:${KAGGLE_KEY}`);
  const endpoint = `https://www.kaggle.com/api/v1/datasets/list?search=${encodeURIComponent(query)}&pageSize=25`;

  try {
    const res = await fetch(endpoint, {
      headers: { "Authorization": `Basic ${auth}` }
    });

    if (!res.ok) {
      const errorText = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status}: ${res.statusText} - ${errorText}`);
    }
    
    const data = await res.json();

    // Clear skeleton loader
    container.innerHTML = "";

    if (!data.length) {
      container.innerHTML = `
        <div style="text-align: center; padding: 40px; color: #8A95A3;">
          <i class="fas fa-chart-bar" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.5;"></i>
          <h3>No Datasets Found</h3>
          <p>Try searching with different data science keywords</p>
        </div>
      `;
      return;
    }

    let scoredDatasets = data.map(ds => {
      const downloads = ds.downloadCount || 0;
      const usability = ds.usabilityRating || 0;
      const score = (0.5 * downloads) + (0.5 * usability * 1000);
      return { ...ds, score };
    });

    scoredDatasets.sort((a, b) => b.score - a.score);

    scoredDatasets.forEach((ds, idx) => {
      const title = ds.title || "Untitled Dataset";
      const desc = ds.subtitle || "No description";
      const link = `https://www.kaggle.com/datasets/${ds.ref}`;
      container.innerHTML += `
        <div class="result-card">
          <a href="${link}" target="_blank">
            <h3>${title}</h3>
            <p>${desc.slice(0, 150)}...</p>
            <p><strong>Rank ${idx + 1}</strong></p>
          </a>
        </div>
      `;
    });
  } catch (error) {
    console.error('Kaggle search error:', error);
    container.innerHTML = `
      <div class="error-message" style="text-align: center; padding: 40px; color: #EF4444;">
        <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 20px;"></i>
        <h3>Error Fetching Datasets</h3>
        <p>Unable to retrieve Kaggle datasets. This could be due to:</p>
        <ul style="text-align: left; max-width: 500px; margin: 20px auto; color: #B8C5D1;">
          <li>Kaggle API authentication issues</li>
          <li>Invalid API credentials</li>
          <li>Network connectivity issues</li>
          <li>CORS restrictions (Kaggle API may not support browser requests)</li>
        </ul>
        <p style="font-size: 0.9rem; color: #8A95A3; margin-top: 15px;">Error: ${error.message || 'Network error'}</p>
        <p style="font-size: 0.85rem; color: #6B7280; margin-top: 10px;">
          Note: Kaggle API typically requires server-side requests due to CORS policies.
        </p>
      </div>
    `;
  }
}

// Load Home tab by default when page loads
window.addEventListener('DOMContentLoaded', function () {
  goHome();
  initializeFeedbackForm();
});

// Feedback Form Handler
function initializeFeedbackForm() {
  const feedbackForm = document.getElementById('feedbackForm');
  if (!feedbackForm) return;

  feedbackForm.addEventListener('submit', async function (e) {
    e.preventDefault();

    const submitBtn = this.querySelector('.feedback-submit-btn');
    const responseDiv = document.getElementById('feedbackResponse');

    // Get form data
    const formData = new FormData(this);
    const data = {
      name: formData.get('name').trim(),
      email: formData.get('email').trim(),
      feedback: formData.get('feedback').trim()
    };

    // Basic validation
    if (!data.name || !data.email || !data.feedback) {
      showFeedbackResponse('Please fill in all required fields.', 'error');
      return;
    }

    if (!isValidEmail(data.email)) {
      showFeedbackResponse('Please enter a valid email address.', 'error');
      return;
    }

    if (data.feedback.length < 10) {
      showFeedbackResponse('Please provide more detailed feedback (at least 10 characters).', 'error');
      return;
    }

    // Disable button and show loading
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';

    try {
      const response = await fetch('send_feedback.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams(data)
      });

      const result = await response.json();

      if (result.success) {
        showFeedbackResponse(result.message, 'success');
        // Reset form
        this.reset();
      } else {
        showFeedbackResponse(result.message, 'error');
      }

    } catch (error) {
      console.error('Feedback submission error:', error);
      showFeedbackResponse('Network error. Please check your connection and try again.', 'error');
    } finally {
      // Re-enable button
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Feedback';
    }
  });
}

function showFeedbackResponse(message, type) {
  const responseDiv = document.getElementById('feedbackResponse');
  responseDiv.textContent = message;
  responseDiv.className = `feedback-response ${type}`;
  responseDiv.style.display = 'block';

  // Auto-hide success messages after 10 seconds
  if (type === 'success') {
    setTimeout(() => {
      responseDiv.style.display = 'none';
    }, 10000);
  }

  // Scroll to response
  responseDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}