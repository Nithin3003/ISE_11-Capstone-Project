<?php
// Alternative email implementation using PHPMailer
// Uncomment and install PHPMailer via Composer for production use
/*
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function send_feedback_email($form_data) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = '84msnithin@gmail.com';
        $mail->Password = 'hyjy rgfb vctd plub'; // Use App Password for Gmail
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Recipients
        $mail->setFrom('84msnithin@gmail.com', 'Study Search Engine');
        $mail->addAddress('84msnithin@gmail.com', 'Admin'); // Admin email
        $mail->addReplyTo($form_data['email'], $form_data['name']);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Study Search Engine Feedback from ' . $form_data['name'];

        $admin_message = "
        <html>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
            <div style='max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;'>
                <h2 style='color: #6366f1; border-bottom: 2px solid #6366f1; padding-bottom: 10px;'>
                    🎯 New Study Search Engine Feedback
                </h2>

                <div style='background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0;'>
                    <h3 style='margin: 0 0 10px 0; color: #495057;'>Contact Information</h3>
                    <p><strong>Name:</strong> " . htmlspecialchars($form_data['name']) . "</p>
                    <p><strong>Email:</strong> <a href='mailto:" . htmlspecialchars($form_data['email']) . "'>" . htmlspecialchars($form_data['email']) . "</a></p>
                </div>

                <div style='background: #fff; padding: 15px; border-left: 4px solid #6366f1; margin: 20px 0;'>
                    <h3 style='margin: 0 0 10px 0; color: #495057;'>Feedback Message</h3>
                    <p style='white-space: pre-wrap;'>" . nl2br(htmlspecialchars($form_data['feedback'])) . "</p>
                </div>

                <div style='background: #e9ecef; padding: 10px; border-radius: 5px; font-size: 0.9em; color: #6c757d;'>
                    <p><strong>Submitted:</strong> " . date('Y-m-d H:i:s') . "</p>
                    <p><strong>IP:</strong> " . $_SERVER['REMOTE_ADDR'] . "</p>
                </div>
            </div>
        </body>
        </html>
        ";

        $mail->Body = $admin_message;
        $mail->AltBody = strip_tags($admin_message);

        $mail->send();

        // Send confirmation to user
        $mail->clearAddresses();
        $mail->clearReplyTos();
        $mail->addAddress($form_data['email'], $form_data['name']);

        $mail->Subject = '✅ Thank you for your Study Search Engine feedback!';

        $user_message = "
        <html>
        <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
            <div style='max-width: 600px; margin: 0 auto; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px;'>
                <div style='background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);'>
                    <div style='text-align: center; margin-bottom: 30px;'>
                        <h1 style='color: #6366f1; margin: 0;'>✅ Thank You!</h1>
                        <p style='color: #666; margin: 10px 0 0 0;'>Your feedback has been received</p>
                    </div>

                    <p>Dear <strong>" . htmlspecialchars($form_data['name']) . "</strong>,</p>

                    <p>Thank you for taking the time to share your feedback on <strong>Study Search Engine</strong>! 🎉</p>

                    <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #6366f1;'>
                        <p style='margin: 0;'><strong>What happens next?</strong></p>
                        <ul style='margin: 10px 0 0 0; padding-left: 20px;'>
                            <li>Our team will review your feedback within 24-48 hours</li>
                            <li>We'll consider your suggestions for future updates</li>
                            <li>If needed, we may reach out for clarification</li>
                        </ul>
                    </div>

                    <p>Your input is invaluable in helping us create a better learning resource discovery experience for everyone.</p>

                    <div style='background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 20px 0;'>
                        <p style='margin: 0; font-size: 0.9em; color: #1976d2;'>
                            💡 <strong>Tip:</strong> Keep using Study Search Engine to discover amazing learning resources across videos, code, papers, and datasets!
                        </p>
                    </div>

                    <p>Best regards,<br>
                    <strong>The Study Search Engine Team</strong> 📚</p>

                    <hr style='border: none; border-top: 1px solid #eee; margin: 30px 0;'>
                    <p style='font-size: 0.8em; color: #999; text-align: center;'>
                        This is an automated message. Please do not reply to this email.<br>
                        Sent on: " . date('Y-m-d H:i:s') . "
                    </p>
                </div>
            </div>
        </body>
        </html>
        ";

        $mail->Body = $user_message;
        $mail->AltBody = strip_tags($user_message);

        $mail->send();

        return array(true, "Thank you " . htmlspecialchars($form_data['name']) . "! Your feedback has been sent successfully. Check your email for confirmation.");

    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $mail->ErrorInfo);
        return array(false, "There was an issue sending your feedback. Your message has been saved and we'll respond soon.");
    }
}
*/
?>