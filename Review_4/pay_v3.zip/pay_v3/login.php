<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | Study Search Engine</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
  <div class="container">
    <div class="form-container">
      <h1>Welcome Back</h1>
      <form action="login_action.php" method="POST">
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-user"></i>
            <input type="text" name="username" placeholder="Enter your User ID" required>
          </div>
        </div>
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Enter your Password" required>
          </div>
        </div>
        <button type="submit">Login to Dashboard</button>
      </form>
      <p>New to our platform? <a href="register.php">Create an account</a></p>
      <p><a href="main.php">← Back to Home</a></p>
    </div>
  </div>
</body>
</html>