<?php
// Database connection (XAMPP default: user = root, no password)
$host = "localhost";
$dbname = "study_search_db";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("DB Connection Failed: " . $e->getMessage());
    die("Database connection error. Please try again later.");
}
?>
