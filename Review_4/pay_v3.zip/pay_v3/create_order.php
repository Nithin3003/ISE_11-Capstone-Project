<?php
session_start();
require_once 'db.php';
require_once 'razorpay_config.php';
require_once 'csrf_helper.php';
require_once 'vendor/autoload.php';

use Razorpay\Api\Api;

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Verify CSRF Token
if (!isset($input['csrf_token']) || !verifyCsrfToken($input['csrf_token'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
    exit();
}

if (!isset($input['plan_id']) || !isset($input['amount'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit();
}

$plan_id = intval($input['plan_id']);
$amount = floatval($input['amount']);

try {
    // Fetch plan details
    $stmt = $pdo->prepare("SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1");
    $stmt->execute([$plan_id]);
    $plan = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$plan) {
        echo json_encode(['success' => false, 'message' => 'Invalid plan selected']);
        exit();
    }
    
    // Verify amount matches
    if ($plan['amount'] != $amount) {
        echo json_encode(['success' => false, 'message' => 'Amount mismatch']);
        exit();
    }
    
    // Get user email
    $stmt = $pdo->prepare("SELECT email, username FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Initialize Razorpay API
    $api = new Api(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET);
    
    // Convert amount to paise (Razorpay requires amount in smallest currency unit)
    $amount_in_paise = intval($amount * 100);
    
    // Generate unique receipt ID
    $receipt = 'order_' . $user_id . '_' . time();
    
    // Create Razorpay order
    $orderData = [
        'receipt'         => $receipt,
        'amount'          => $amount_in_paise,
        'currency'        => RAZORPAY_CURRENCY,
        'payment_capture' => 1 // Auto capture
    ];
    
    $razorpayOrder = $api->order->create($orderData);
    
    // Save order in database
    $stmt = $pdo->prepare("
        INSERT INTO orders (user_id, razorpay_order_id, amount, currency, receipt, status) 
        VALUES (?, ?, ?, ?, ?, 'created')
    ");
    $stmt->execute([
        $user_id,
        $razorpayOrder['id'],
        $amount,
        RAZORPAY_CURRENCY,
        $receipt
    ]);
    
    $order_id = $pdo->lastInsertId();
    
    // Return order details to frontend
    echo json_encode([
        'success' => true,
        'order' => [
            'order_id' => $order_id,
            'razorpay_order_id' => $razorpayOrder['id'],
            'amount' => $amount_in_paise,
            'currency' => RAZORPAY_CURRENCY,
            'key_id' => RAZORPAY_KEY_ID,
            'email' => $user['email'],
            'contact' => '',
            'plan_name' => $plan['name']
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Order creation error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Failed to create order: ' . $e->getMessage()
    ]);
}
?>
