// YouTube API Key - Make sure this is loaded before script.js
const YOUTUBE_API_KEY = "AIzaSyAS5QQocs7B9I2b7Szo_6FN591dgYFv7Lg";

// Kaggle API Credentials
const KAGGLE_USERNAME = "adityakapoorrao";
const KAGGLE_KEY = "1705865f15f7a81a6d7d8b105e881240";

// Log to verify API key is loaded
console.log('Config.js loaded successfully');
console.log('YouTube API Key status:', YOUTUBE_API_KEY ? 'Loaded' : 'Missing');
