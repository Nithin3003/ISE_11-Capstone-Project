<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) exit;

$user_id = $_SESSION['user_id'];

// Fetch last searched query
$stmt = $pdo->prepare("SELECT query FROM search_history WHERE user_id=? ORDER BY searched_at DESC LIMIT 1");
$stmt->execute([$user_id]);
$query = $stmt->fetchColumn();

echo json_encode([$query]);
?>