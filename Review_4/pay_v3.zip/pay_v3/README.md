# 🔍 Study Search Engine

A comprehensive multi-source search platform with integrated payment system, allowing users to search across YouTube videos, research papers, GitHub repositories, and Kaggle datasets.

## ✨ Features

### 🔎 Multi-Source Search

- **YouTube Videos** - Search educational videos
- **Research Papers** - Access arXiv research papers
- **GitHub Repositories** - Find code repositories
- **Kaggle Datasets** - Discover datasets

### 👤 User Management

- User registration and authentication
- Secure login system with CSRF protection
- Profile management
- Search history tracking

### 💳 Payment & Subscription

- **3 Subscription Tiers**: Free, Premium (₹48/month), Pro (₹89/month)
- **Razorpay Payment Integration** - Support for Cards, UPI, Net Banking, Wallets
- **Subscription Management** - View active plans, history, cancel anytime
- Secure payment processing with signature verification

### 📊 User Dashboard

- Current subscription status display
- Payment history
- Search analytics
- Subscription cancellation

## 🚀 Quick Start

### Prerequisites

- XAMPP (Apache + MySQL + PHP 7.4+)
- Composer
- Razorpay account
- API Keys: YouTube Data API v3, Kaggle

### Installation

1. **Clone/Copy** this folder to `C:\xampp\htdocs\`

2. **Install Dependencies**

   ```bash
   composer install
   ```

   Or run: `install_dependencies.bat`

3. **Setup Database**

   - Open phpMyAdmin: `http://localhost/phpmyadmin`
   - Create database: `study_search_db`
   - Import: `database_setup.sql`

4. **Configure Settings**

   **Database** (`db.php`):

   ```php
   $host = 'localhost';
   $dbname = 'study_search_db';
   $username = 'root';
   $password = '';
   ```

   **Razorpay** (`razorpay_config.php`):

   ```php
   $keyId = 'YOUR_RAZORPAY_KEY_ID';
   $keySecret = 'YOUR_RAZORPAY_KEY_SECRET';
   ```

   **API Keys** (`config.js` and `config.php`):

   - YouTube API Key
   - Kaggle Username & Key

5. **Start Application**
   - Start XAMPP (Apache + MySQL)
   - Visit: `http://localhost/Final_payments/`

## 📁 Project Structure

```
Final_payments/
├── index.php              # Main search interface
├── main.php               # Search page
├── login.php              # User login
├── register.php           # User registration
├── payments.php           # Subscription plans page
├── my_subscription.php    # User subscription dashboard
├── cancel_subscription.php # Cancel subscription endpoint
├── verify_payment.php     # Razorpay payment verification
├── create_order.php       # Create Razorpay order
├── api_proxy.php          # API proxy for CORS handling
├── db.php                 # Database connection
├── config.js              # Frontend API configuration
├── config.php             # Backend API configuration
├── razorpay_config.php    # Payment gateway config
├── style.css              # Main stylesheet
├── payments.css           # Payment page styles
├── script.js              # Search functionality
├── payments.js            # Payment processing
├── database_setup.sql     # Complete database schema
└── vendor/                # Composer dependencies
```

## 🎯 Usage

1. **Register** a new account
2. **Login** to access search features
3. **Search** across multiple platforms
4. **Upgrade** to Premium/Pro for enhanced features
5. **Manage** subscription from dashboard

## 🔐 Subscription Plans

| Plan        | Price     | Features                                    |
| ----------- | --------- | ------------------------------------------- |
| **Free**    | ₹0        | 10 searches/day, Basic features             |
| **Premium** | ₹48/month | 100 searches/day, Ad-free, Priority support |
| **Pro**     | ₹89/month | Unlimited searches, API access, Analytics   |

## 🛠️ Technologies

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Backend**: PHP 7.4+
- **Database**: MySQL
- **Payment**: Razorpay
- **APIs**: YouTube Data API, arXiv API, GitHub API, Kaggle API
- **Dependencies**: PHPMailer, Razorpay PHP SDK

## 📝 Configuration Files

- `db.php` - Database credentials
- `config.js` - Frontend API keys
- `config.php` - Backend config (Email, APIs)
- `razorpay_config.php` - Payment gateway keys

## 🐛 Troubleshooting

**Database Error**: Check MySQL is running, verify `db.php` credentials

**Payment Not Working**: Verify Razorpay keys, ensure test mode is enabled

**API Errors**: Check API keys in `config.js`, verify quotas

**Email Issues**: Use Gmail App Password, enable 2FA

## 📄 License

This project is for educational purposes.

## 👨‍💻 Developer

For detailed setup instructions, refer to `SETUP_INSTRUCTIONS.md`
