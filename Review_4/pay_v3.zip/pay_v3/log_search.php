<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) exit;

$user_id = $_SESSION['user_id'];
$query = $_POST['query'] ?? '';
$type = $_POST['type'] ?? 'all';

$stmt = $pdo->prepare("INSERT INTO search_history (user_id, query, type) VALUES (?, ?, ?)");
$stmt->execute([$user_id, $query, $type]);

echo "OK";
?>