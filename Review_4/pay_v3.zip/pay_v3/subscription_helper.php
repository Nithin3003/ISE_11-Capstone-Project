<?php
/**
 * Subscription Helper Functions
 * Include this file to check and manage user subscriptions
 */

/**
 * Check if a user has an active subscription
 * @param int $user_id User ID
 * @return bool True if user has active subscription
 */
function hasActiveSubscription($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM user_subscriptions 
        WHERE user_id = ? AND is_active = 1 AND end_date > NOW()
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn() > 0;
}

/**
 * Get user's active subscription details
 * @param int $user_id User ID
 * @return array|false Subscription details or false if none
 */
function getActiveSubscription($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT us.*, sp.name as plan_name, sp.amount, sp.features, sp.duration_days
        FROM user_subscriptions us 
        JOIN subscription_plans sp ON us.plan_id = sp.id 
        WHERE us.user_id = ? AND us.is_active = 1 AND us.end_date > NOW()
        ORDER BY us.end_date DESC 
        LIMIT 1
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Get days remaining in subscription
 * @param int $user_id User ID
 * @return int|false Days remaining or false if no subscription
 */
function getSubscriptionDaysRemaining($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT DATEDIFF(end_date, NOW()) as days_remaining
        FROM user_subscriptions 
        WHERE user_id = ? AND is_active = 1 AND end_date > NOW()
        ORDER BY end_date DESC 
        LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result ? (int)$result['days_remaining'] : false;
}

/**
 * Check if user has a specific feature
 * @param int $user_id User ID
 * @param string $feature Feature name to check
 * @return bool True if user has the feature
 */
function hasFeature($user_id, $feature) {
    $subscription = getActiveSubscription($user_id);
    if (!$subscription) {
        return false;
    }
    
    $features = json_decode($subscription['features'], true);
    return in_array($feature, $features);
}

/**
 * Require active subscription or redirect to payment page
 * @param int $user_id User ID
 * @param string $redirect_url URL to redirect if no subscription (default: payments.php)
 */
function requirePremium($user_id, $redirect_url = 'payments.php') {
    if (!hasActiveSubscription($user_id)) {
        header("Location: $redirect_url");
        exit();
    }
}

/**
 * Get all user's payment history
 * @param int $user_id User ID
 * @return array Payment history
 */
function getUserPaymentHistory($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT p.*, o.receipt, o.created_at as order_date
        FROM payments p
        JOIN orders o ON p.order_id = o.id
        WHERE o.user_id = ?
        ORDER BY p.created_at DESC
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get subscription statistics for admin
 * @return array Subscription statistics
 */
function getSubscriptionStats() {
    global $pdo;
    
    $stats = [];
    
    // Total active subscriptions
    $stmt = $pdo->query("
        SELECT COUNT(*) as count 
        FROM user_subscriptions 
        WHERE is_active = 1 AND end_date > NOW()
    ");
    $stats['active_subscriptions'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Total revenue
    $stmt = $pdo->query("
        SELECT SUM(amount) as total 
        FROM payments 
        WHERE status IN ('captured', 'authorized')
    ");
    $stats['total_revenue'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    
    // Revenue by plan
    $stmt = $pdo->query("
        SELECT sp.name, COUNT(us.id) as subscriptions, SUM(p.amount) as revenue
        FROM user_subscriptions us
        JOIN subscription_plans sp ON us.plan_id = sp.id
        JOIN payments p ON us.payment_id = p.id
        WHERE p.status IN ('captured', 'authorized')
        GROUP BY sp.id
    ");
    $stats['revenue_by_plan'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    return $stats;
}

/**
 * Cancel user subscription
 * @param int $user_id User ID
 * @return bool True if cancelled successfully
 */
function cancelSubscription($user_id) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            UPDATE user_subscriptions 
            SET is_active = 0, auto_renew = 0 
            WHERE user_id = ? AND is_active = 1
        ");
        $stmt->execute([$user_id]);
        return true;
    } catch (Exception $e) {
        error_log("Error cancelling subscription: " . $e->getMessage());
        return false;
    }
}

/**
 * Display subscription badge
 * @param int $user_id User ID
 * @return string HTML badge
 */
function displaySubscriptionBadge($user_id) {
    $subscription = getActiveSubscription($user_id);
    
    if (!$subscription) {
        return '<span class="badge badge-free">Free</span>';
    }
    
    $plan_name = htmlspecialchars($subscription['plan_name']);
    $days_remaining = getSubscriptionDaysRemaining($user_id);
    
    return '<span class="badge badge-premium" title="' . $days_remaining . ' days remaining">' 
           . $plan_name . ' ✓</span>';
}

/**
 * Check if subscription is expiring soon (within 7 days)
 * @param int $user_id User ID
 * @return bool True if expiring soon
 */
function isSubscriptionExpiringSoon($user_id) {
    $days_remaining = getSubscriptionDaysRemaining($user_id);
    return $days_remaining !== false && $days_remaining <= 7;
}
?>
