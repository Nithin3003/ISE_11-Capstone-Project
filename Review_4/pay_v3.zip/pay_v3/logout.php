<?php
session_start();
session_unset();
session_destroy();

// Redirect to landing page (main.php)
header("Location: main.php");
exit;
?>
