<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    // Get active subscription
    $stmt = $pdo->prepare("
        SELECT us.*, sp.name as plan_name, sp.amount 
        FROM user_subscriptions us 
        JOIN subscription_plans sp ON us.plan_id = sp.id 
        WHERE us.user_id = ? AND us.is_active = 1 AND us.end_date > NOW()
        ORDER BY us.end_date DESC LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $active_subscription = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$active_subscription) {
        echo json_encode(['success' => false, 'message' => 'No active subscription found']);
        exit();
    }
    
    // Don't allow canceling free plans
    if ($active_subscription['amount'] == 0) {
        echo json_encode(['success' => false, 'message' => 'Cannot cancel free plan']);
        exit();
    }
    
    // Update subscription to inactive
    $stmt = $pdo->prepare("
        UPDATE user_subscriptions 
        SET is_active = 0, cancelled_at = NOW() 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$active_subscription['id'], $user_id]);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Subscription cancelled successfully. You can continue using premium features until ' . 
                     date('F j, Y', strtotime($active_subscription['end_date']))
    ]);
    
} catch (PDOException $e) {
    error_log("Cancel subscription error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to cancel subscription. Please try again.']);
}
?>
