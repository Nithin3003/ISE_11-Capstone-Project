<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user info
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Get active subscription
$stmt = $pdo->prepare("
    SELECT us.*, sp.name as plan_name, sp.amount, sp.features, sp.duration_days,
           DATEDIFF(us.end_date, NOW()) as days_remaining
    FROM user_subscriptions us 
    JOIN subscription_plans sp ON us.plan_id = sp.id 
    WHERE us.user_id = ? AND us.is_active = 1 AND us.end_date > NOW()
    ORDER BY us.end_date DESC LIMIT 1
");
$stmt->execute([$user_id]);
$active_subscription = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if subscription was cancelled
$is_cancelled = false;
if ($active_subscription) {
    $stmt = $pdo->prepare("SELECT cancelled_at FROM user_subscriptions WHERE id = ?");
    $stmt->execute([$active_subscription['id']]);
    $cancel_info = $stmt->fetch(PDO::FETCH_ASSOC);
    $is_cancelled = !empty($cancel_info['cancelled_at']);
}

// Get subscription history
$stmt = $pdo->prepare("
    SELECT us.*, sp.name as plan_name, sp.amount, 
           p.razorpay_payment_id, p.method, p.status as payment_status
    FROM user_subscriptions us
    JOIN subscription_plans sp ON us.plan_id = sp.id
    JOIN payments p ON us.payment_id = p.id
    WHERE us.user_id = ?
    ORDER BY us.created_at DESC
");
$stmt->execute([$user_id]);
$subscription_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Subscription - Study Search Engine</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .subscription-container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 20px;
        }
        
        .user-header {
            background: linear-gradient(145deg, #232B3D 0%, #1A2332 100%);
            padding: 30px;
            border-radius: 20px;
            margin-bottom: 30px;
            border: 2px solid rgba(0, 210, 255, 0.3);
        }
        
        .user-header h2 {
            color: #00D2FF;
            margin-bottom: 10px;
        }
        
        .user-info {
            color: #B8C5D1;
            font-size: 1.1rem;
        }
        
        .status-card {
            background: linear-gradient(145deg, #232B3D 0%, #1A2332 100%);
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            border: 3px solid;
            text-align: center;
        }
        
        .status-card.active {
            border-color: #10B981;
            box-shadow: 0 20px 60px rgba(16, 185, 129, 0.3);
        }
        
        .status-card.inactive {
            border-color: rgba(255, 255, 255, 0.2);
        }
        
        .status-badge {
            display: inline-block;
            padding: 10px 25px;
            border-radius: 25px;
            font-weight: 700;
            font-size: 1.1rem;
            margin-bottom: 20px;
        }
        
        .status-badge.active {
            background: linear-gradient(135deg, #10B981 0%, #059669 100%);
            color: white;
        }
        
        .status-badge.inactive {
            background: rgba(255, 255, 255, 0.1);
            color: #8A95A3;
        }
        
        .plan-title {
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin: 15px 0;
        }
        
        .plan-amount {
            font-size: 3rem;
            font-weight: 900;
            color: #00D2FF;
            margin: 20px 0;
        }
        
        .plan-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .detail-item {
            background: rgba(0, 210, 255, 0.1);
            padding: 20px;
            border-radius: 15px;
            border: 1px solid rgba(0, 210, 255, 0.3);
        }
        
        .detail-label {
            color: #8A95A3;
            font-size: 0.9rem;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        
        .detail-value {
            color: #00D2FF;
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .features-section {
            background: linear-gradient(145deg, #232B3D 0%, #1A2332 100%);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            border: 2px solid rgba(0, 210, 255, 0.2);
        }
        
        .features-section h3 {
            color: #00D2FF;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }
        
        .features-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            color: #B8C5D1;
            padding: 12px;
            background: rgba(0, 210, 255, 0.05);
            border-radius: 10px;
        }
        
        .feature-item i {
            color: #10B981;
            margin-right: 12px;
            font-size: 1.2rem;
        }
        
        .history-section {
            background: linear-gradient(145deg, #232B3D 0%, #1A2332 100%);
            border-radius: 20px;
            padding: 30px;
            border: 2px solid rgba(0, 210, 255, 0.2);
        }
        
        .history-section h3 {
            color: #00D2FF;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        th {
            color: #00D2FF;
            font-weight: 600;
        }
        
        td {
            color: #B8C5D1;
        }
        
        .payment-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .payment-status.captured {
            background: rgba(16, 185, 129, 0.2);
            color: #10B981;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            justify-content: center;
        }
        
        .btn {
            padding: 15px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s ease;
            display: inline-block;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #00D2FF 0%, #3A7BD5 100%);
            color: white;
            box-shadow: 0 10px 30px rgba(0, 210, 255, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(0, 210, 255, 0.5);
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            color: #B8C5D1;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.15);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);
            color: white;
            box-shadow: 0 10px 30px rgba(239, 68, 68, 0.3);
        }
        
        .btn-danger:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(239, 68, 68, 0.5);
        }
        
        .cancel-warning {
            background: rgba(239, 68, 68, 0.1);
            border: 2px solid rgba(239, 68, 68, 0.3);
            border-radius: 15px;
            padding: 20px;
            margin-top: 30px;
            color: #B8C5D1;
        }
        
        .cancel-warning h4 {
            color: #EF4444;
            margin-bottom: 15px;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: linear-gradient(145deg, #232B3D 0%, #1A2332 100%);
            border-radius: 20px;
            padding: 40px;
            max-width: 500px;
            border: 2px solid rgba(239, 68, 68, 0.3);
        }
        
        .modal-content h3 {
            color: #EF4444;
            margin-bottom: 20px;
        }
        
        .modal-content p {
            color: #B8C5D1;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .modal-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
        }
    </style>
</head>
<body>
    <div class="subscription-container">
        <a href="index.php" class="back-link" style="color: #00D2FF; text-decoration: none; font-size: 1.1rem; margin-bottom: 20px; display: inline-block;">
            <i class="fas fa-arrow-left"></i> Back to Home
        </a>
        
        <div class="user-header">
            <h2><i class="fas fa-user"></i> <?php echo htmlspecialchars($user['username']); ?></h2>
            <p class="user-info"><?php echo htmlspecialchars($user['email']); ?></p>
        </div>
        
        <?php if ($active_subscription): ?>
        <div class="status-card active">
            <div class="status-badge active">
                <i class="fas fa-check-circle"></i> <?php echo $is_cancelled ? 'ACTIVE (CANCELLED)' : 'ACTIVE SUBSCRIPTION'; ?>
            </div>
            <?php if ($is_cancelled): ?>
            <div style="background: rgba(239, 68, 68, 0.2); padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                <p style="color: #EF4444; margin: 0; font-weight: 600;">
                    <i class="fas fa-info-circle"></i> Your subscription has been cancelled and will not auto-renew.
                </p>
            </div>
            <?php endif; ?>
            <div class="plan-title"><?php echo htmlspecialchars($active_subscription['plan_name']); ?></div>
            <div class="plan-amount">₹<?php echo number_format($active_subscription['amount'], 2); ?>/month</div>
            
            <div class="plan-details">
                <div class="detail-item">
                    <div class="detail-label">Days Remaining</div>
                    <div class="detail-value"><?php echo $active_subscription['days_remaining']; ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Started On</div>
                    <div class="detail-value"><?php echo date('M j, Y', strtotime($active_subscription['start_date'])); ?></div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Expires On</div>
                    <div class="detail-value"><?php echo date('M j, Y', strtotime($active_subscription['end_date'])); ?></div>
                </div>
            </div>
            
            <?php if ($active_subscription['amount'] > 0 && !$is_cancelled): ?>
            <div class="cancel-warning">
                <h4><i class="fas fa-exclamation-triangle"></i> Cancel Subscription</h4>
                <p>Canceling your subscription will end automatic renewal. You'll continue to have access to premium features until <strong><?php echo date('F j, Y', strtotime($active_subscription['end_date'])); ?></strong>.</p>
                <button onclick="showCancelModal()" class="btn btn-danger">
                    <i class="fas fa-times-circle"></i> Cancel Subscription
                </button>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="features-section">
            <h3><i class="fas fa-star"></i> Your Features</h3>
            <div class="features-list">
                <?php 
                $features = json_decode($active_subscription['features'], true);
                foreach ($features as $feature): 
                ?>
                <div class="feature-item">
                    <i class="fas fa-check"></i>
                    <span><?php echo htmlspecialchars($feature); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="status-card inactive">
            <div class="status-badge inactive">
                <i class="fas fa-times-circle"></i> NO ACTIVE SUBSCRIPTION
            </div>
            <p style="color: #B8C5D1; font-size: 1.2rem; margin: 20px 0;">You don't have an active subscription yet.</p>
            <a href="payments.php" class="btn btn-primary" style="margin-top: 20px;">
                <i class="fas fa-crown"></i> Upgrade Now
            </a>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($subscription_history)): ?>
        <div class="history-section">
            <h3><i class="fas fa-history"></i> Subscription History</h3>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Plan</th>
                            <th>Amount</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($subscription_history as $sub): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($sub['plan_name']); ?></td>
                            <td>₹<?php echo number_format($sub['amount'], 2); ?></td>
                            <td><?php echo date('M j, Y', strtotime($sub['start_date'])); ?></td>
                            <td><?php echo date('M j, Y', strtotime($sub['end_date'])); ?></td>
                            <td><?php echo htmlspecialchars($sub['method'] ?? 'N/A'); ?></td>
                            <td>
                                <span class="payment-status captured">
                                    <?php echo $sub['is_active'] && strtotime($sub['end_date']) > time() ? 'Active' : 'Expired'; ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="btn-group">
            <?php if (!$active_subscription): ?>
            <a href="payments.php" class="btn btn-primary">
                <i class="fas fa-crown"></i> View Plans
            </a>
            <?php endif; ?>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-home"></i> Back to Home
            </a>
        </div>
    </div>
    
    <!-- Cancel Confirmation Modal -->
    <div id="cancelModal" class="modal">
        <div class="modal-content">
            <h3><i class="fas fa-exclamation-triangle"></i> Confirm Cancellation</h3>
            <p>Are you sure you want to cancel your subscription? You'll lose access to premium features after <strong><?php echo $active_subscription ? date('F j, Y', strtotime($active_subscription['end_date'])) : ''; ?></strong>.</p>
            <div class="modal-buttons">
                <button onclick="confirmCancel()" class="btn btn-danger">
                    <i class="fas fa-check"></i> Yes, Cancel
                </button>
                <button onclick="closeCancelModal()" class="btn btn-secondary">
                    <i class="fas fa-times"></i> No, Keep It
                </button>
            </div>
        </div>
    </div>
    
    <script>
        function showCancelModal() {
            document.getElementById('cancelModal').classList.add('active');
        }
        
        function closeCancelModal() {
            document.getElementById('cancelModal').classList.remove('active');
        }
        
        async function confirmCancel() {
            try {
                const response = await fetch('cancel_subscription.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            } catch (error) {
                alert('Failed to cancel subscription. Please try again.');
            }
            
            closeCancelModal();
        }
        
        // Close modal when clicking outside
        document.getElementById('cancelModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeCancelModal();
            }
        });
    </script>
</body>
</html>
