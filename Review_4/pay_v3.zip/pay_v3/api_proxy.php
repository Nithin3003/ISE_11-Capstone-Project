<?php
/**
 * API Proxy to bypass CORS restrictions
 * Handles requests to external APIs that don't support CORS
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// Get the API type and query parameters
$api_type = $_GET['api'] ?? '';
$query = $_GET['query'] ?? '';

if (empty($api_type) || empty($query)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing api or query parameter']);
    exit;
}

try {
    switch ($api_type) {
        case 'arxiv':
            proxyArxiv($query);
            break;
        
        case 'kaggle':
            proxyKaggle($query);
            break;
        
        case 'youtube':
            proxyYouTube($query);
            break;
        
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid API type']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

/**
 * Proxy for arXiv API
 */
function proxyArxiv($query) {
    $encoded_query = urlencode($query);
    $url = "https://export.arxiv.org/api/query?search_query=all:{$encoded_query}&start=0&max_results=25";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        throw new Exception("cURL Error: " . $error);
    }
    
    curl_close($ch);
    
    if ($http_code !== 200) {
        http_response_code($http_code);
        echo json_encode(['error' => "HTTP {$http_code} from arXiv API"]);
        exit;
    }
    
    // Return XML as JSON with the XML content
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'xml' => $response,
        'type' => 'arxiv'
    ]);
}

/**
 * Proxy for Kaggle API
 */
function proxyKaggle($query) {
    // Get Kaggle credentials from config
    require_once 'config.php';
    
    if (!defined('KAGGLE_USERNAME') || !defined('KAGGLE_KEY')) {
        throw new Exception("Kaggle credentials not configured");
    }
    
    $encoded_query = urlencode($query);
    $url = "https://www.kaggle.com/api/v1/datasets/list?search={$encoded_query}&pageSize=25";
    
    $auth = base64_encode(KAGGLE_USERNAME . ':' . KAGGLE_KEY);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Basic {$auth}",
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        throw new Exception("cURL Error: " . $error);
    }
    
    curl_close($ch);
    
    if ($http_code !== 200) {
        http_response_code($http_code);
        echo json_encode(['error' => "HTTP {$http_code} from Kaggle API"]);
        exit;
    }
    
    // Return the JSON response
    header('Content-Type: application/json');
    echo $response;
}

/**
 * Proxy for YouTube API
 * Note: YouTube API requires a valid API key. This is a fallback using search scraping.
 */
function proxyYouTube($query) {
    require_once 'config.php';
    
    // Check if YouTube API key is defined
    if (!defined('YOUTUBE_API_KEY')) {
        // Fallback: Return mock data or error
        echo json_encode([
            'success' => false,
            'error' => 'YouTube API key not configured or quota exceeded',
            'message' => 'YouTube API is currently unavailable. Please configure a valid API key.',
            'quota_exceeded' => true
        ]);
        exit;
    }
    
    $encoded_query = urlencode($query);
    $url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=25&q={$encoded_query}&key=" . YOUTUBE_API_KEY;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        throw new Exception("cURL Error: " . $error);
    }
    
    curl_close($ch);
    
    // Check for quota exceeded or forbidden
    if ($http_code === 403) {
        $response_data = json_decode($response, true);
        $error_message = $response_data['error']['message'] ?? 'API quota exceeded';
        
        echo json_encode([
            'success' => false,
            'error' => $error_message,
            'quota_exceeded' => true,
            'message' => 'YouTube API quota has been exceeded. Quota resets daily at midnight PST.',
            'solutions' => [
                'Wait for quota reset (midnight PST/Pacific Time)',
                'Use YouTube.com directly for searches',
                'Get a new API key from Google Cloud Console',
                'Request quota increase (up to 1M units/day)',
                'Consider using multiple API keys for high traffic'
            ],
            'quota_info' => [
                'daily_limit' => '10,000 units',
                'cost_per_search' => '~100 units',
                'reset_time' => 'Midnight PST',
                'console_url' => 'https://console.cloud.google.com/apis/credentials'
            ]
        ]);
        exit;
    }
    
    if ($http_code !== 200) {
        http_response_code($http_code);
        echo json_encode([
            'success' => false,
            'error' => "HTTP {$http_code} from YouTube API"
        ]);
        exit;
    }
    
    // Return the JSON response
    header('Content-Type: application/json');
    echo $response;
}
?>
