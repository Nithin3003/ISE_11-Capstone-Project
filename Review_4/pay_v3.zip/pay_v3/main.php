<?php
session_start();
// If already logged in, go straight to index.php
if (isset($_SESSION['user_id'])) {
  header("Location: index.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome | Study Search Engine</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
  <div class="home-wrapper">
    <div class="landing-container">
      <div class="hero-section">
        <div class="hero-content">
          <h1><i class="fas fa-search"></i> Study Search Engine</h1>
          <p class="hero-description">
            A unified platform to discover <strong>Videos, Code, Research Papers, and Datasets</strong>.  
            Powered by smart ranking and recommendations to make your research journey easier and more productive.  
            Join thousands of researchers, students, and developers who trust our platform for their academic needs.
          </p>
          <div class="landing-buttons">
            <a href="login.php"><button class="btn-primary">Login</button></a>
            <a href="register.php"><button class="btn-secondary">Get Started</button></a>
          </div>
        </div>
      </div>
      
      <div class="features-section">
        <h3 class="features-title">
          <i class="fas fa-sparkles"></i> What makes us special?
        </h3>
        <div class="features-grid">
          <div class="feature-card">
            <div class="feature-icon">
              <i class="fas fa-video"></i>
            </div>
            <h4>Smart Video Search</h4>
            <p>Find educational content from top platforms like YouTube, Coursera, and more</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">
              <i class="fas fa-code"></i>
            </div>
            <h4>Code Discovery</h4>
            <p>Access GitHub repositories and code samples from the developer community</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">
              <i class="fas fa-file-alt"></i>
            </div>
            <h4>Research Papers</h4>
            <p>Latest academic publications and studies from trusted sources</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">
              <i class="fas fa-chart-bar"></i>
            </div>
            <h4>Dataset Hub</h4>
            <p>Quality datasets for your machine learning and research projects</p>
          </div>
        </div>
      </div>

      <div class="stats-section">
        <div class="stats-grid">
          <div class="stat-item">
            <div class="stat-number">10K+</div>
            <div class="stat-label">Active Users</div>
          </div>
          <div class="stat-item">
            <div class="stat-number">50K+</div>
            <div class="stat-label">Resources</div>
          </div>
          <div class="stat-item">
            <div class="stat-number">99%</div>
            <div class="stat-label">Uptime</div>
          </div>
          <div class="stat-item">
            <div class="stat-number">24/7</div>
            <div class="stat-label">Support</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>