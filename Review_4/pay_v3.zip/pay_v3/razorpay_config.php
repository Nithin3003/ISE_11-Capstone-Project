<?php
// Razorpay Configuration
// Get your API keys from https://dashboard.razorpay.com/app/keys

define('RAZORPAY_KEY_ID', 'rzp_test_R8fwnvtYI2KF1j');
define('RAZORPAY_KEY_SECRET', 'vX6WpUPqNIktfTGlLfDJChq9');

// Test Mode Keys (for development)
// define('RAZORPAY_KEY_ID', 'rzp_test_xxxxxxxxxxxxx');
// define('RAZORPAY_KEY_SECRET', 'xxxxxxxxxxxxxxxxxxxxxxxxx');

// Live Mode Keys (for production)
// define('RAZORPAY_KEY_ID', 'rzp_live_xxxxxxxxxxxxx');
// define('RAZORPAY_KEY_SECRET', 'xxxxxxxxxxxxxxxxxxxxxxxxx');

// Currency
define('RAZORPAY_CURRENCY', 'INR');

// Company Details (shown in payment popup)
define('RAZORPAY_MERCHANT_NAME', 'Study Search Engine');
define('RAZORPAY_MERCHANT_LOGO', 'https://yourwebsite.com/logo.png'); // Optional
?>
