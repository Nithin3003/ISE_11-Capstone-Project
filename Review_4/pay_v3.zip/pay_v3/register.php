<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register | Study Search Engine</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
  <div class="container">
    <div class="form-container">
      <h1>Join Us</h1>
      <form action="register_action.php" method="POST">
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-user-edit"></i>
            <input type="text" name="name" placeholder="Full Name" required>
          </div>
        </div>
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-envelope"></i>
            <input type="email" name="email" placeholder="Email Address" required>
          </div>
        </div>
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-graduation-cap"></i>
            <input type="text" name="college" placeholder="College/University Name">
          </div>
        </div>
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-map-marker-alt"></i>
            <input type="text" name="city" placeholder="City">
          </div>
        </div>
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-user"></i>
            <input type="text" name="username" placeholder="Choose a User ID" required>
          </div>
        </div>
        <div class="form-group">
          <div class="input-group">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Create Password" required>
          </div>
        </div>
        <button type="submit">Create Account</button>
      </form>
      <p>Already have an account? <a href="login.php">Sign in here</a></p>
      <p><a href="main.php">← Back to Home</a></p>
    </div>
  </div>
</body>
</html>
