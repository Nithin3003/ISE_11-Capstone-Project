<?php
session_start();
require_once 'db.php';
require_once 'csrf_helper.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Generate CSRF token
$csrf_token = generateCsrfToken();

// Fetch subscription plans
try {
    $stmt = $pdo->prepare("SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY amount ASC");
    $stmt->execute();
    $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching plans: " . $e->getMessage());
}

// Fetch user's active subscription (if any)
$active_subscription = null;
try {
    $stmt = $pdo->prepare("
        SELECT us.*, sp.name as plan_name, sp.amount, sp.id as plan_id,
               DATEDIFF(us.end_date, NOW()) as days_remaining
        FROM user_subscriptions us 
        JOIN subscription_plans sp ON us.plan_id = sp.id 
        WHERE us.user_id = ? AND us.is_active = 1 AND us.end_date > NOW()
        ORDER BY us.end_date DESC LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $active_subscription = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Active subscription query error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo $csrf_token; ?>">
    <title>Subscription Plans - Study Search Engine</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="payments.css">
</head>
<body>
    <div class="payment-container">
        <a href="main.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Search
        </a>
        
        <div class="page-header">
            <h1>💎 Subscription Plans</h1>
            <p>Choose the perfect plan for your learning journey</p>
        </div>
        
        <?php if ($active_subscription): ?>
        <div class="current-plan-banner">
            <i class="fas fa-check-circle"></i>
            <div class="banner-content">
                <h3>Active: <?php echo htmlspecialchars($active_subscription['plan_name']); ?> Plan</h3>
                <p>
                    <?php if ($active_subscription['amount'] > 0): ?>
                        Valid for <strong><?php echo $active_subscription['days_remaining']; ?> more days</strong> 
                        (expires <?php echo date('M j, Y', strtotime($active_subscription['end_date'])); ?>)
                    <?php else: ?>
                        Enjoying the Free plan
                    <?php endif; ?>
                </p>
            </div>
            <?php if ($active_subscription['amount'] > 0): ?>
            <a href="my_subscription.php">
                <i class="fas fa-history"></i> View History
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div class="plans-grid">
            <?php foreach ($plans as $index => $plan): 
                $features = json_decode($plan['features'], true);
                $is_featured = ($index == 1); // Make middle plan featured
                $is_current = $active_subscription && $active_subscription['plan_id'] == $plan['id'];
                $is_free = $plan['amount'] == 0;
            ?>
            <div class="plan-card <?php echo $is_featured ? 'featured' : ''; ?> <?php echo $is_current ? 'current-plan' : ''; ?>">
                <?php if ($is_featured): ?>
                    <div class="plan-badge">⭐ BEST VALUE</div>
                <?php endif; ?>
                
                <div class="plan-name"><?php echo htmlspecialchars($plan['name']); ?></div>
                <div class="plan-price">
                    <?php if ($is_free): ?>
                        <span style="font-size: 3rem;">FREE</span>
                    <?php else: ?>
                        <sup>₹</sup><?php echo number_format($plan['amount'], 0); ?>
                    <?php endif; ?>
                </div>
                <div class="plan-duration">
                    <?php echo $is_free ? 'Forever' : $plan['duration_days'] . ' days access'; ?>
                </div>
                <div class="plan-description">
                    <?php echo htmlspecialchars($plan['description']); ?>
                </div>
                
                <ul class="plan-features">
                    <?php foreach ($features as $feature): ?>
                        <li><?php echo htmlspecialchars($feature); ?></li>
                    <?php endforeach; ?>
                </ul>
                
                <button class="subscribe-btn <?php echo $is_current ? 'current' : ''; ?>" 
                        onclick="<?php echo $is_current ? 'return false;' : "initiatePayment({$plan['id']}, '" . htmlspecialchars($plan['name']) . "', {$plan['amount']})"; ?>"
                        <?php echo $is_current ? 'disabled' : ''; ?>>
                    <?php if ($is_current): ?>
                        <i class="fas fa-check-circle"></i> Your Active Plan
                    <?php elseif ($is_free): ?>
                        <i class="fas fa-infinity"></i> Free Forever
                    <?php else: ?>
                        <i class="fas fa-rocket"></i> Get Started
                    <?php endif; ?>
                </button>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="payment-info">
            <h3><i class="fas fa-shield-alt"></i> Secure Payment Guarantee</h3>
            <p><i class="fas fa-check"></i> All payments processed securely through Razorpay</p>
            <p><i class="fas fa-check"></i> Your card information is never stored on our servers</p>
            <p><i class="fas fa-check"></i> Cancel anytime - no questions asked</p>
            <p><i class="fas fa-check"></i> Instant activation after successful payment</p>
        </div>
        
        <div class="payment-methods">
            <span class="method-label">Accepted Payment Methods:</span>
            <div class="payment-method"><i class="fas fa-credit-card"></i> Credit Card</div>
            <div class="payment-method"><i class="fas fa-credit-card"></i> Debit Card</div>
            <div class="payment-method"><i class="fas fa-university"></i> Net Banking</div>
            <div class="payment-method"><i class="fas fa-mobile-alt"></i> UPI</div>
            <div class="payment-method"><i class="fas fa-wallet"></i> Wallets</div>
        </div>
    </div>
    
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script src="payments.js"></script>
</body>
</html>
