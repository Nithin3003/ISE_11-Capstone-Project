<?php
session_start();
require_once 'db.php';
require_once 'razorpay_config.php';
require_once 'vendor/autoload.php';

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['razorpay_payment_id']) || !isset($input['razorpay_order_id']) || 
    !isset($input['razorpay_signature']) || !isset($input['order_id'])) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit();
}

$razorpay_payment_id = $input['razorpay_payment_id'];
$razorpay_order_id = $input['razorpay_order_id'];
$razorpay_signature = $input['razorpay_signature'];
$order_id = intval($input['order_id']);

try {
    // Fetch order from database
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
    $stmt->execute([$order_id, $user_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit();
    }
    
    // Verify order ID matches
    if ($order['razorpay_order_id'] !== $razorpay_order_id) {
        echo json_encode(['success' => false, 'message' => 'Order ID mismatch']);
        exit();
    }
    
    // Initialize Razorpay API
    $api = new Api(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET);
    
    // Verify signature
    $attributes = [
        'razorpay_order_id' => $razorpay_order_id,
        'razorpay_payment_id' => $razorpay_payment_id,
        'razorpay_signature' => $razorpay_signature
    ];
    
    try {
        $api->utility->verifyPaymentSignature($attributes);
        $signature_verified = true;
    } catch (SignatureVerificationError $e) {
        $signature_verified = false;
        error_log("Signature verification failed: " . $e->getMessage());
    }
    
    if (!$signature_verified) {
        // Update order status to failed
        $stmt = $pdo->prepare("UPDATE orders SET status = 'failed' WHERE id = ?");
        $stmt->execute([$order_id]);
        
        echo json_encode(['success' => false, 'message' => 'Payment signature verification failed']);
        exit();
    }
    
    // Fetch payment details from Razorpay
    $payment = $api->payment->fetch($razorpay_payment_id);
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Update order status
        $stmt = $pdo->prepare("UPDATE orders SET status = 'paid' WHERE id = ?");
        $stmt->execute([$order_id]);
        
        // Insert payment record
        $stmt = $pdo->prepare("
            INSERT INTO payments 
            (order_id, razorpay_payment_id, razorpay_order_id, razorpay_signature, 
             amount, currency, status, method, email, contact) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $order_id,
            $razorpay_payment_id,
            $razorpay_order_id,
            $razorpay_signature,
            $payment['amount'] / 100, // Convert from paise to rupees
            $payment['currency'],
            $payment['status'],
            $payment['method'] ?? null,
            $payment['email'] ?? null,
            $payment['contact'] ?? null
        ]);
        
        $payment_id = $pdo->lastInsertId();
        
        // Try to create subscription if tables exist
        $subscription_created = false;
        try {
            // Check if subscription tables exist
            $stmt = $pdo->query("SHOW TABLES LIKE 'subscription_plans'");
            $plans_table_exists = $stmt->rowCount() > 0;
            
            $stmt = $pdo->query("SHOW TABLES LIKE 'user_subscriptions'");
            $subscriptions_table_exists = $stmt->rowCount() > 0;
            
            if ($plans_table_exists && $subscriptions_table_exists) {
                // Get plan details from the order amount
                $stmt = $pdo->prepare("
                    SELECT sp.* 
                    FROM subscription_plans sp 
                    WHERE sp.amount = ? AND sp.is_active = 1 
                    LIMIT 1
                ");
                $stmt->execute([$order['amount']]);
                $plan = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($plan) {
                    // Create or update user subscription
                    // First, deactivate any existing active subscriptions
                    $stmt = $pdo->prepare("
                        UPDATE user_subscriptions 
                        SET is_active = 0 
                        WHERE user_id = ? AND is_active = 1
                    ");
                    $stmt->execute([$user_id]);
                    
                    // Calculate end date
                    $end_date = date('Y-m-d H:i:s', strtotime('+' . $plan['duration_days'] . ' days'));
                    
                    // Create new subscription
                    $stmt = $pdo->prepare("
                        INSERT INTO user_subscriptions 
                        (user_id, plan_id, payment_id, end_date, is_active) 
                        VALUES (?, ?, ?, ?, 1)
                    ");
                    $stmt->execute([$user_id, $plan['id'], $payment_id, $end_date]);
                    $subscription_created = true;
                }
            }
        } catch (Exception $sub_error) {
            // Log subscription error but don't fail the payment
            error_log("Subscription creation failed: " . $sub_error->getMessage());
        }
        
        // Commit transaction
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Payment verified successfully',
            'payment_id' => $razorpay_payment_id,
            'subscription_active' => $subscription_created
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log("Payment verification error: " . $e->getMessage());
    
    // Try to save failed payment attempt
    try {
        $stmt = $pdo->prepare("
            INSERT INTO payments 
            (order_id, razorpay_payment_id, razorpay_order_id, razorpay_signature, 
             amount, currency, status, error_description) 
            VALUES (?, ?, ?, ?, ?, ?, 'failed', ?)
        ");
        $stmt->execute([
            $order_id ?? null,
            $razorpay_payment_id ?? null,
            $razorpay_order_id ?? null,
            $razorpay_signature ?? null,
            $order['amount'] ?? 0,
            $order['currency'] ?? 'INR',
            $e->getMessage()
        ]);
    } catch (Exception $e2) {
        error_log("Failed to log payment error: " . $e2->getMessage());
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'Payment verification failed: ' . $e->getMessage()
    ]);
}
?>
