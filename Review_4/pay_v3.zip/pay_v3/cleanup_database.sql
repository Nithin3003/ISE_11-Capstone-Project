-- Cleanup existing tables with foreign key constraints
USE study_search_db;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS user_subscriptions;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS subscription_plans;
DROP TABLE IF EXISTS search_history;
DROP TABLE IF EXISTS feedback_rate_limits;
DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;
