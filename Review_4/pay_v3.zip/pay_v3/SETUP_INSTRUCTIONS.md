# Study Search Engine - Complete Setup Guide

## 📋 Prerequisites

- XAMPP installed (Apache + MySQL + PHP)
- Composer installed
- Razorpay account (for payments)
- Email account for SMTP (optional)

## 🚀 Quick Setup

### Step 1: Database Setup

1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Create database: `study_search_db`
3. Import the SQL file: `database_setup.sql`
4. Run this additional SQL to add cancelled_at column:

```sql
ALTER TABLE user_subscriptions
ADD COLUMN cancelled_at DATETIME NULL DEFAULT NULL
AFTER is_active;
```

### Step 2: Install Dependencies

Run in terminal:

```bash
composer install
```

Or double-click: `install_dependencies.bat`

### Step 3: Configure Database

Edit `db.php` and update if needed:

```php
$host = 'localhost';
$dbname = 'study_search_db';
$username = 'root';
$password = ''; // Your MySQL password
```

### Step 4: Configure Razorpay Payment

Edit `razorpay_config.php`:

```php
$keyId = 'YOUR_RAZORPAY_KEY_ID';
$keySecret = 'YOUR_RAZORPAY_KEY_SECRET';
```

### Step 5: Configure API Keys

Edit `config.js`:

```javascript
const YOUTUBE_API_KEY = "YOUR_YOUTUBE_API_KEY";
const KAGGLE_USERNAME = "YOUR_KAGGLE_USERNAME";
const KAGGLE_KEY = "YOUR_KAGGLE_API_KEY";
```

Edit `config.php`:

```php
define('YOUTUBE_API_KEY', 'YOUR_YOUTUBE_API_KEY');
```

### Step 6: Configure Email (Optional)

Edit `config.php` for email settings:

```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
```

### Step 7: Start Application

1. Start XAMPP (Apache + MySQL)
2. Open browser: `http://localhost/Final_payments/`
3. Register a new account
4. Test the search functionality

## 📁 Important Files

### Core Files

- `index.php` - Main search page
- `main.php` - Search interface
- `login.php` / `register.php` - Authentication
- `payments.php` - Subscription plans
- `my_subscription.php` - User subscription management
- `verify_payment.php` - Razorpay payment verification
- `cancel_subscription.php` - Cancel subscription endpoint

### Configuration Files

- `db.php` - Database connection
- `config.js` - Frontend API keys
- `config.php` - Backend API keys & email config
- `razorpay_config.php` - Payment gateway config

### Database Files

- `database_setup.sql` - Complete database structure

### Style Files

- `style.css` - Main styles
- `payments.css` - Payment page styles

### JavaScript Files

- `script.js` - Search functionality
- `payments.js` - Payment processing
- `form-enhance.js` - Form enhancements

## 🔐 Default Subscription Plans

After running `database_setup.sql`, you'll have:

- **Free Plan**: ₹0 - Basic features
- **Premium Plan**: ₹48/30 days - Enhanced features
- **Pro Plan**: ₹89/30 days - All features

## 🎯 Features

1. **Multi-Source Search**

   - YouTube videos
   - Research papers (arXiv)
   - GitHub repositories
   - Kaggle datasets

2. **User Management**

   - Registration/Login
   - Profile management
   - Subscription status tracking

3. **Payment Integration**

   - Razorpay payment gateway
   - Multiple payment methods (Cards, UPI, Wallets, Net Banking)
   - Secure payment processing

4. **Subscription Management**
   - View active subscription
   - Subscription history
   - Cancel subscription
   - Automatic renewal tracking

## 🐛 Troubleshooting

### Database Connection Error

- Check MySQL is running in XAMPP
- Verify credentials in `db.php`
- Ensure database `study_search_db` exists

### Payment Not Working

- Verify Razorpay keys in `razorpay_config.php`
- Check Razorpay dashboard for test mode
- Ensure `orders` and `payments` tables exist

### API Errors

- Verify API keys in `config.js`
- Check YouTube API quota
- Test API proxy: `api_proxy.php`

### Email Not Sending

- Use Gmail App Password (not regular password)
- Enable 2FA and generate App Password
- Update SMTP settings in `config.php`

## 📞 Support

For issues, check the browser console and PHP error logs in XAMPP.
