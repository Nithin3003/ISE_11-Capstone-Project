<?php
session_start();
require_once 'db.php';
require_once 'subscription_helper.php';

// Simple admin check - you should implement proper admin authentication
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get statistics
$stats = getSubscriptionStats();

// Get recent payments
$stmt = $pdo->query("
    SELECT p.*, o.user_id, u.username, u.email, sp.name as plan_name
    FROM payments p
    JOIN orders o ON p.order_id = o.id
    JOIN users u ON o.user_id = u.id
    LEFT JOIN user_subscriptions us ON us.payment_id = p.id
    LEFT JOIN subscription_plans sp ON us.plan_id = sp.id
    ORDER BY p.created_at DESC
    LIMIT 20
");
$recent_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get subscription counts by plan
$stmt = $pdo->query("
    SELECT sp.name, COUNT(us.id) as active_count
    FROM subscription_plans sp
    LEFT JOIN user_subscriptions us ON sp.id = us.plan_id 
        AND us.is_active = 1 
        AND us.end_date > NOW()
    GROUP BY sp.id
    ORDER BY sp.amount ASC
");
$plan_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Dashboard - Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .admin-container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 20px;
        }
        
        .dashboard-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
        }
        
        .stat-card h3 {
            margin: 0;
            font-size: 14px;
            opacity: 0.9;
            text-transform: uppercase;
        }
        
        .stat-card .value {
            font-size: 36px;
            font-weight: bold;
            margin: 15px 0;
        }
        
        .section {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .section h2 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-captured {
            background: #d4edda;
            color: #155724;
        }
        
        .status-authorized {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .status-failed {
            background: #f8d7da;
            color: #721c24;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        .plan-distribution {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .plan-stat {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        
        .plan-stat .plan-name {
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
        }
        
        .plan-stat .count {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <a href="main.php" class="back-link">← Back to Main</a>
        
        <div class="dashboard-header">
            <h1>💰 Payment Dashboard</h1>
            <p>Monitor subscriptions and revenue</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Active Subscriptions</h3>
                <div class="value"><?php echo number_format($stats['active_subscriptions']); ?></div>
            </div>
            
            <div class="stat-card">
                <h3>Total Revenue</h3>
                <div class="value">₹<?php echo number_format($stats['total_revenue'], 2); ?></div>
            </div>
            
            <div class="stat-card">
                <h3>Average Per User</h3>
                <div class="value">
                    ₹<?php 
                        $avg = $stats['active_subscriptions'] > 0 
                            ? $stats['total_revenue'] / $stats['active_subscriptions'] 
                            : 0;
                        echo number_format($avg, 2); 
                    ?>
                </div>
            </div>
        </div>
        
        <div class="section">
            <h2>📊 Subscriptions by Plan</h2>
            <div class="plan-distribution">
                <?php foreach ($plan_stats as $plan): ?>
                <div class="plan-stat">
                    <div class="plan-name"><?php echo htmlspecialchars($plan['name']); ?></div>
                    <div class="count"><?php echo number_format($plan['active_count']); ?></div>
                    <div style="color: #666; font-size: 14px;">subscribers</div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="section">
            <h2>📋 Recent Payments</h2>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>User</th>
                            <th>Plan</th>
                            <th>Amount</th>
                            <th>Payment ID</th>
                            <th>Method</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_payments as $payment): ?>
                        <tr>
                            <td><?php echo date('M j, Y H:i', strtotime($payment['created_at'])); ?></td>
                            <td>
                                <?php echo htmlspecialchars($payment['username']); ?><br>
                                <small style="color: #666;"><?php echo htmlspecialchars($payment['email']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($payment['plan_name'] ?? 'N/A'); ?></td>
                            <td>₹<?php echo number_format($payment['amount'], 2); ?></td>
                            <td>
                                <small style="font-family: monospace;">
                                    <?php echo htmlspecialchars(substr($payment['razorpay_payment_id'], 0, 20)); ?>...
                                </small>
                            </td>
                            <td><?php echo htmlspecialchars($payment['method'] ?? 'N/A'); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $payment['status']; ?>">
                                    <?php echo strtoupper($payment['status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        
                        <?php if (empty($recent_payments)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 40px; color: #666;">
                                No payments recorded yet
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="section">
            <h2>💡 Revenue Breakdown by Plan</h2>
            <table>
                <thead>
                    <tr>
                        <th>Plan Name</th>
                        <th>Subscriptions</th>
                        <th>Total Revenue</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($stats['revenue_by_plan'] as $plan): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($plan['name']); ?></td>
                        <td><?php echo number_format($plan['subscriptions']); ?></td>
                        <td>₹<?php echo number_format($plan['revenue'], 2); ?></td>
                        <td>
                            <?php 
                                $percentage = $stats['total_revenue'] > 0 
                                    ? ($plan['revenue'] / $stats['total_revenue']) * 100 
                                    : 0;
                                echo number_format($percentage, 1) . '%'; 
                            ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($stats['revenue_by_plan'])): ?>
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 40px; color: #666;">
                            No revenue data available
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
