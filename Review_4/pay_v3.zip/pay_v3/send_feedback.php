<?php
session_start();
include "db.php";

// Rate limiting: max 3 submissions per hour per IP
$current_time = time();
$client_ip = $_SERVER['REMOTE_ADDR'];
$one_hour_ago = date('Y-m-d H:i:s', $current_time - 3600);

// Clean old rate limit entries
$pdo->prepare("DELETE FROM feedback_rate_limits WHERE submission_time < ?")->execute([$one_hour_ago]);

// Check rate limit for this IP
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM feedback_rate_limits WHERE ip_address = ? AND submission_time >= ?");
$stmt->execute([$client_ip, $one_hour_ago]);
$rate_limit = $stmt->fetch(PDO::FETCH_ASSOC);

if ($rate_limit['count'] >= 3) {
    header('Content-Type: application/json');
    echo json_encode(array('success' => false, 'message' => 'Too many feedback submissions. Please try again later.'));
    exit;
}

// Add current submission to rate limit table
$pdo->prepare("INSERT INTO feedback_rate_limits (ip_address, submission_time) VALUES (?, NOW())")
     ->execute([$client_ip]);

function send_feedback_email($form_data, $pdo, $client_ip) {
    try {
        // Store feedback in database
        $stmt = $pdo->prepare("INSERT INTO feedback (name, email, feedback, ip_address, submitted_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([
            $form_data['name'],
            $form_data['email'],
            $form_data['feedback'],
            $client_ip
        ]);

        // Log the feedback submission for debugging
        error_log(sprintf(
            "[%s] Feedback stored in DB - Name: %s, Email: %s, IP: %s",
            date('Y-m-d H:i:s'),
            $form_data['name'],
            $form_data['email'],
            $client_ip
        ));

        // Simulate email sending delay
        sleep(1);

        return array(true, "Thank you " . htmlspecialchars($form_data['name']) . "! Your feedback has been received successfully. We'll review it and get back to you soon.");

    } catch (Exception $e) {
        error_log("Feedback storage error: " . $e->getMessage());
        return array(false, "There was an issue processing your feedback. Your message has been saved and we'll respond soon.");
    }
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    // Log the request for debugging
    error_log("Feedback request received from IP: " . $_SERVER['REMOTE_ADDR']);
    error_log("POST data: " . print_r($_POST, true));

    // Validate input
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $feedback = trim($_POST['feedback'] ?? '');

    error_log("Processed data - Name: '$name', Email: '$email', Feedback length: " . strlen($feedback));

    if (empty($name) || empty($email) || empty($feedback)) {
        echo json_encode(array('success' => false, 'message' => 'All fields are required.'));
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(array('success' => false, 'message' => 'Please enter a valid email address.'));
        exit;
    }

    if (strlen($name) < 2) {
        echo json_encode(array('success' => false, 'message' => 'Please enter a valid name (at least 2 characters).'));
        exit;
    }

    $form_data = array(
        'name' => $name,
        'email' => $email,
        'feedback' => $feedback
    );

    list($success, $message) = send_feedback_email($form_data, $pdo, $client_ip);

    echo json_encode(array('success' => $success, 'message' => $message));
    exit;
}

// If not POST request, return error
header('Content-Type: application/json');
echo json_encode(array('success' => false, 'message' => 'Invalid request method.'));
?>