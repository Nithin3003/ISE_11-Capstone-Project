function initiatePayment(planId, planName, amount) {
    // Get CSRF token from meta tag
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // Create order first
    fetch('create_order.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken
        },
        body: JSON.stringify({
            plan_id: planId,
            amount: amount,
            csrf_token: csrfToken
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            openRazorpayCheckout(data.order, planName, amount);
        } else {
            alert('Error creating order: ' + (data.message || 'Unknown error'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to initiate payment. Please try again.');
    });
}

function openRazorpayCheckout(order, planName, amount) {
    var options = {
        "key": order.key_id,
        "amount": order.amount,
        "currency": order.currency,
        "name": "Study Search Engine",
        "description": planName,
        "order_id": order.razorpay_order_id,
        "handler": function (response) {
            verifyPayment(response, order.order_id);
        },
        "prefill": {
            "email": order.email || "",
            "contact": order.contact || ""
        },
        "theme": {
            "color": "#667eea"
        },
        "modal": {
            "ondismiss": function() {
                console.log('Payment cancelled by user');
            }
        }
    };
    
    var rzp = new Razorpay(options);
    rzp.open();
}

function verifyPayment(razorpayResponse, orderId) {
    // Get CSRF token from meta tag
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch('verify_payment.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken
        },
        body: JSON.stringify({
            razorpay_payment_id: razorpayResponse.razorpay_payment_id,
            razorpay_order_id: razorpayResponse.razorpay_order_id,
            razorpay_signature: razorpayResponse.razorpay_signature,
            order_id: orderId,
            csrf_token: csrfToken
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('🎉 Payment successful! Your subscription is now active.');
            window.location.reload();
        } else {
            alert('Payment verification failed: ' + (data.message || 'Unknown error'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to verify payment. Please contact support.');
    });
}
