<?php
/**
 * Configuration file for API credentials
 */

// YouTube API Key
define('YOUTUBE_API_KEY', 'AIzaSyAS5QQocs7B9I2b7Szo_6FN591dgYFv7Lg');

// Kaggle API Credentials
define('KAGGLE_USERNAME', 'adityakapoorrao');
define('KAGGLE_KEY', '1705865f15f7a81a6d7d8b105e881240');
?>
