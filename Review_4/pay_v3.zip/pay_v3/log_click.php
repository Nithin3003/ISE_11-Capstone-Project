<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) exit;

$user_id = $_SESSION['user_id'];
$title = $_POST['title'] ?? '';
$link = $_POST['link'] ?? '';
$type = $_POST['type'] ?? 'all';

$stmt = $pdo->prepare("INSERT INTO search_history (user_id, query, type, title, link, clicked) VALUES (?, ?, ?, ?, ?, 1)");
$stmt->execute([$user_id, $title, $type, $title, $link]);

echo "OK";
?>