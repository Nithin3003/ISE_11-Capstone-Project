<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get user's current subscription status
require_once 'db.php';
$user_id = $_SESSION['user_id'];

$current_plan = 'Free';
$plan_badge_class = 'free';
$plan_badge_text = 'FREE';

try {
    $stmt = $pdo->prepare("
        SELECT sp.name, sp.amount, DATEDIFF(us.end_date, NOW()) as days_left
        FROM user_subscriptions us 
        JOIN subscription_plans sp ON us.plan_id = sp.id 
        WHERE us.user_id = ? AND us.is_active = 1 AND us.end_date > NOW()
        ORDER BY us.end_date DESC LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $subscription = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($subscription) {
        $current_plan = $subscription['name'];
        $plan_badge_class = strtolower($subscription['name']);
        $plan_badge_text = strtoupper($subscription['name']);
    }
} catch (Exception $e) {
    error_log("Subscription status error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Study Search Engine</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <script src="config.js"></script>
</head>
<body>
  <div class="container">
    <!-- Top Navigation with Logout -->
    <div class="top-nav">
      <div class="nav-left">
        <h1>Study Search Engine</h1>
      </div>
      <div class="nav-right">
        <form action="logout.php" method="POST" style="display: inline-block;">
          <button type="submit" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i> Logout
          </button>
        </form>
      </div>
    </div>

    <p class="intro">Search across Videos, Code Repositories, Research Papers, and Datasets in one place.</p>

    <!-- Search Bar -->
    <input type="text" id="searchInput" placeholder="Search for a topic...">

    <!-- Search Tabs -->
    <div class="tabs">
      <button onclick="goHome()" class="active">
        <i class="fas fa-home"></i> Home
      </button>
      <button onclick="search('videos')">
        <i class="fas fa-video"></i> Videos
      </button>
      <button onclick="search('code')">
        <i class="fas fa-code"></i> Code
      </button>
      <button onclick="search('papers')">
        <i class="fas fa-file-alt"></i> Papers
      </button>
      <button onclick="search('datasets')">
        <i class="fas fa-chart-bar"></i> Datasets
      </button>
    </div>

    <!-- Recommendation Text -->
    <div id="recommendationBox" class="recommendation-box"></div>

    <!-- Results Section (empty initially, populated dynamically) -->
    <div id="results"></div>

    <!-- Feedback Section -->
    <div class="feedback-section">
      <div class="feedback-container">
        <h3><i class="fas fa-comments"></i> Share Your Feedback</h3>
        <p>Help us improve Study Search Engine! Your feedback is valuable to us.</p>

        <form id="feedbackForm" class="feedback-form">
          <div class="form-row">
            <div class="form-group">
              <label for="feedbackName">Name *</label>
              <input type="text" id="feedbackName" name="name" required placeholder="Your full name">
            </div>
            <div class="form-group">
              <label for="feedbackEmail">Email *</label>
              <input type="email" id="feedbackEmail" name="email" required placeholder="your.email@example.com">
            </div>
          </div>

          <div class="form-group">
            <label for="feedbackMessage">Your Feedback *</label>
            <textarea id="feedbackMessage" name="feedback" required placeholder="Tell us what you think about Study Search Engine... What features do you love? What can we improve? Any bugs you've encountered?" rows="5"></textarea>
          </div>

          <button type="submit" class="feedback-submit-btn">
            <i class="fas fa-paper-plane"></i> Send Feedback
          </button>
        </form>

        <div id="feedbackResponse" class="feedback-response" style="display: none;"></div>
      </div>
    </div>
  </div>

  <script src="script.js"></script>
</body>
</html>
